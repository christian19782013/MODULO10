// Global properties and methods
// CD Framework 1.2 Module
// Rupert Davies - 2002-07-11
// Customised for PISM 1.1
// (c) 2002 TSO


//  ***  Properties  ***

var appVersion = "2_0";
var appName = "ss";

var enablePageStore = true;
var enableSearch = true;
var enableToc = true;
var enableHistory = true;
var enableBookmarks = true;
var enableSession = true;

var defaultPageId = "ss_2";
var currentPageId = "";
var currentPageURL = "";

var envProtocol = "";
var envRoot = "";
var searchActive = false;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


// *** Methods ***

function globalInit() {
checkBrowser();
discoverEnvironment();
if (top.frames['applets'].appletsEnabled) {
	searchActive = true;
	}
if (enablePageStore) {
	pageStore.init();
	}
if (enableSearch) {
	search.init();
	}
if (enableToc) {
	tocStore.init();
	}
if (enableHistory) {
	viewHistory.init();
	}
if (enableSession) {
	session.load();
	}
display.init();
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function globalExit() {
if (enableSession) {
	session.save();
	}
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function discoverEnvironment() {
var locStr=window.top.location.toString();
if (locStr.indexOf("file://") != -1 ) {
	envProtocol = "file";
	}
else if (locStr.indexOf("http://") != -1) {
	envProtocol = "http";
	}
else {
	envProtocol = "unknown";
	}
var pos = locStr.lastIndexOf("/");
envRoot = locStr.substring(0,pos);
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


// Main page load function called by each page passing that page's id
function pageLoad(pageId) {
top.scripts.currentPageId = pageId;
top.scripts.ui.checkPageFeatures(pageId);
top.scripts.display.title(top.scripts.pageStore.getTitle(pageId));
if (enableToc && top.scripts.ui.navMode == "toc" && top.scripts.tocStore.inToc(top.scripts.tocStore.currentToc, pageId)) {
	top.scripts.tocStore[top.scripts.tocStore.currentToc].currentPage = pageId;
	top.scripts.display.highlightToc();
	}
if (enableHistory && top.scripts.ui.enableAddToHistory && top.scripts.ui.navMode != "history") {
	top.scripts.viewHistory.add(pageId);
	}
if (enableBookmarks) {
	display.updateBookmarkFlag(pageId);
	}
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


// EOF