// bookmarks object
// CD Framework 1.1  Module
// Rupert Davies - 2001-11-20
// (c) 2001 TSO

// *** Objects ***

var bookmarks = new Object();
bookmarks.store = new Object();

function bookmarkItem(title, href) {
	this.title = title;
	this.href = href;
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// *** Properties ***

bookmarks.count = 0;	// not currently used
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// *** Methods ***

function bookmarksToggle(pageId) {
if (pageId == null) {
	pageId = top.scripts.currentPageId;
	}
if (bookmarks.store[pageId]) {
	bookmarks.store[pageId] = null;
	}
else {
	var title = top.scripts.pageStore.getTitle(pageId);
	var href = top.scripts.pageStore.getHref(pageId);
	bookmarks.store[pageId] = new bookmarkItem(title, href);
	}
}
bookmarks.toggle = bookmarksToggle;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function bookmarksCheck(pageId) {
if (pageId == null) {
	pageId = top.scripts.currentPageId;
	}
if (bookmarks.store[pageId]) {
	return true;
	}
else {
	return false;
	}
}
bookmarks.check = bookmarksCheck;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


function bookmarksClear(pageId) {
if (bookmarks.store[pageId]) {
	bookmarks.store[pageId] = null;
	}
}
bookmarks.clear = bookmarksClear;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function bookmarksFirstPageId() {
for (var obj in this.store) {
	if (this.store[obj] != null) {
		var pageId = obj;
		return pageId;
		}
	}
return "";
}
bookmarks.firstPageId = bookmarksFirstPageId;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function bookmarksSerialise() {
var strSerialised = "";
for (var obj in bookmarks.store) {
	if (bookmarks.store[obj] != null) {
		strSerialised = strSerialised + obj + "@";
		}
	}
return strSerialised;
}
bookmarks.serialise = bookmarksSerialise;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function bookmarksDeserialise(strSerialised) {
var entries = strSerialised.split("@");
for (var i=0; i<entries.length; i++) {
	var pageId = entries[i];
	if (top.scripts.pageStore.exists(pageId)) {
		var title = top.scripts.pageStore.getTitle(pageId);
		var href = top.scripts.pageStore.getHref(pageId);
		bookmarks.store[pageId] = new bookmarkItem(title, href);
		}
	}
}
bookmarks.deserialise = bookmarksDeserialise;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

// EOF