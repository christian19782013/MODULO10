// menubar functions
// CD Framework 1.2 Module
// Rupert Davies - 2002-06-17
// (c) TSO 2002

var buttHome = null;
var buttShowHide = null;
var buttToc = null;
var buttBookmarks = null;
var buttHistory = null;
var buttPrev = null;
var buttNext = null;
var buttAdvSearch = null;
var buttGlossary = null;
var buttHelp = null;
var buttExecSearch = null;

function menubarInit() {
buttHome = new top.scripts.uiButton(
	getObjRef(document, "bHome"),
	"active",
	"",
	newImage("chrome/home_a.gif"),
	newImage("chrome/home_o.gif")
	);
buttShowHide = new top.scripts.uiButton(
	getObjRef(document, "bShowHide"),
	"active",
	"top.scripts.ui.showHide();",
	newImage("chrome/showhide_a.gif"),
	newImage("chrome/showhide_o.gif"),
	newImage("chrome/showhide_d.gif")
	);
buttToc = new top.scripts.uiButton(
	getObjRef(document, "bToc"),
	"active",
	"top.scripts.ui.showToc();",
	newImage("chrome/toc_a.gif"),
	newImage("chrome/toc_o.gif")
	);
buttBookmarks = new top.scripts.uiButton(
	getObjRef(document, "bBookmarks"),
	"active",
	"top.scripts.ui.showBookmarks();",
	newImage("chrome/bookmark_a.gif"),
	newImage("chrome/bookmark_o.gif")
	);
buttHistory = new top.scripts.uiButton(
	getObjRef(document, "bHistory"),
	"active",
	"top.scripts.ui.showHistory();",
	newImage("chrome/history_a.gif"),
	newImage("chrome/history_o.gif")
	);
/*
buttPrev = new top.scripts.uiButton(
	getObjRef(document, "bPrev"),
	"active",
	"top.scripts.ui.prev();",
	newImage("chrome/prev_a.gif"),
	newImage("chrome/prev_o.gif"),
	newImage("chrome/prev_d.gif")
	);
buttNext = new top.scripts.uiButton(
	getObjRef(document, "bNext"),
	"active",
	"top.scripts.ui.next();",
	newImage("chrome/next_a.gif"),
	newImage("chrome/next_o.gif"),
	newImage("chrome/next_d.gif")
	);
buttAdvSearch = new top.scripts.uiButton(
	getObjRef(document, "bAdvSearch"),
	"disabled",
	"",
	newImage("chrome/advsearch_a.gif"),
	newImage("chrome/advsearch_o.gif"),
	newImage("chrome/advsearch_d.gif")
	);
*/
buttGlossary = new top.scripts.uiButton(
	getObjRef(document, "bGlossary"),
	"active",
	"",
	newImage("chrome/glossary_a.gif"),
	newImage("chrome/glossary_o.gif")
	);
buttHelp = new top.scripts.uiButton(
	getObjRef(document, "bHelp"),
	"active",
	"",
	newImage("chrome/help_a.gif"),
	newImage("chrome/help_o.gif")
	);
buttExecSearch = new top.scripts.uiButton(
	getObjRef(document, "bExecSearch"),
	"disabled",
	"top.frames['menubar'].submitSearch();",
	newImage("chrome/execsearch_a.gif"),
	newImage("chrome/execsearch_o.gif"),
	newImage("chrome/execsearch_d.gif")
	);

if (top.scripts.searchActive) {
	buttExecSearch.stateChange('active');
	// buttAdvSearch.stateChange('active');
	}

}

function getObjRef(doc, id) {
var objRef = null;
if (top.scripts.DOM) {
	objRef = doc.getElementById(id);
	}
else if (top.scripts.IE) {
	objRef = doc.all[id];
	}
else if (top.scripts.NS) {
	eval("objRef = doc." + id);
	}
return objRef;
}

function newImage(arg) {
if (document.images) {
	rslt = new Image();
	rslt.src = arg;
	return rslt;
	}
}

// Search functions
function submitSearch() {
var strQuery = document.quickSearch.queryText.value;
if (strQuery != "") {
	top.scripts.ui.submitSearch(strQuery);
	}
else {
	top.scripts.display.alert("No search entered.");
	}
}

// EOF