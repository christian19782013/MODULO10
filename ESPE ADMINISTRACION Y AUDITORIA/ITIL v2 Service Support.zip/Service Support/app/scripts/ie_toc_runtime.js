// IE ToC Runtime Functions
// Version 1.0 - Rupert Davies
// (c) TSO 2001

var plus=new Image();
plus.src="../images/plus.gif";
var minus=new Image();
minus.src="../images/minus.gif";

function ieStart(tocId) {
if (tocId=="" || tocId==null) {
	tocId = top.scripts.tocStore.currentToc;
	}
var lgt = top.scripts.tocStore[tocId].root.length;
var elmImg = "";
for (i=1; i<lgt; i++) {
	if (top.scripts.tocStore[tocId].root[i].branch[1]) {
		elmImg = "exp"+i;
		elmDiv = "sub"+i;
		if (top.scripts.tocStore[tocId].root[i].state) {
			document.all[elmImg].src = minus.src;
			document.all[elmDiv].style.display = "";
			}
		else {
			document.all[elmImg].src = plus.src;
			document.all[elmDiv].style.display = "none";
			}
		}
	}
top.scripts.display.highlightToc();
}


function show(elm) {
if (elm.style.display=='none') { elm.style.display=''; }
else if (elm.style.display=='') { elm.style.display='none'; }
}


function swap(elm) {
if (elm.src==plus.src) {elm.src=minus.src;}
else if (elm.src==minus.src) {elm.src=plus.src;}
}


// EOF