// tocStore data
// ITIL Series - TOC data
// Version 1.0
// Rupert Davies - 2002-06-26

function initTocStoreData() {

tocStore.currentToc = "contents";

// toc - id: contents

tocStore.contents = new toc("","ss_2",0,0,0);

tocStore.contents.root = new Array();


tocStore.contents.root[1] = new tocItem("ss_2","",0,0);

tocStore.contents.root[2] = new tocItem("ss_5","",0,0);

tocStore.contents.root[2].branch = new Array();

tocStore.contents.root[2].branch[1] = new tocItem("ss_6","",0,0);
tocStore.contents.root[2].branch[2] = new tocItem("ss_7","",0,0);
tocStore.contents.root[2].branch[3] = new tocItem("ss_8","",0,0);
tocStore.contents.root[2].branch[4] = new tocItem("ss_9","",0,0);
tocStore.contents.root[2].branch[5] = new tocItem("ss_10","",0,0);
tocStore.contents.root[2].branch[6] = new tocItem("ss_11","",0,0);
tocStore.contents.root[2].branch[7] = new tocItem("ss_12","",0,0);
tocStore.contents.root[2].branch[8] = new tocItem("ss_13","",0,0);
tocStore.contents.root[2].branch[9] = new tocItem("ss_14","",0,0);
tocStore.contents.root[2].branch[10] = new tocItem("ss_15","",0,0);
tocStore.contents.root[2].branch[11] = new tocItem("ss_16","",0,0);

tocStore.contents.root[3] = new tocItem("ss_17","",0,0);

tocStore.contents.root[3].branch = new Array();

tocStore.contents.root[3].branch[1] = new tocItem("ss_18","",0,0);
tocStore.contents.root[3].branch[2] = new tocItem("ss_19","",0,0);
tocStore.contents.root[3].branch[3] = new tocItem("ss_20","",0,0);
tocStore.contents.root[3].branch[4] = new tocItem("ss_21","",0,0);
tocStore.contents.root[3].branch[5] = new tocItem("ss_22","",0,0);
tocStore.contents.root[3].branch[6] = new tocItem("ss_23","",0,0);
tocStore.contents.root[3].branch[7] = new tocItem("ss_24","",0,0);
tocStore.contents.root[3].branch[8] = new tocItem("ss_25","",0,0);
tocStore.contents.root[3].branch[9] = new tocItem("ss_26","",0,0);
tocStore.contents.root[3].branch[10] = new tocItem("ss_27","",0,0);
tocStore.contents.root[3].branch[11] = new tocItem("ss_28","",0,0);
tocStore.contents.root[3].branch[12] = new tocItem("ss_29","",0,0);
tocStore.contents.root[3].branch[13] = new tocItem("ss_30","",0,0);
tocStore.contents.root[3].branch[14] = new tocItem("ss_31","",0,0);
tocStore.contents.root[3].branch[15] = new tocItem("ss_32","",0,0);
tocStore.contents.root[3].branch[16] = new tocItem("ss_33","",0,0);
tocStore.contents.root[3].branch[17] = new tocItem("ss_34","",0,0);

tocStore.contents.root[4] = new tocItem("ss_35","",0,0);

tocStore.contents.root[4].branch = new Array();

tocStore.contents.root[4].branch[1] = new tocItem("ss_36","",0,0);
tocStore.contents.root[4].branch[2] = new tocItem("ss_37","",0,0);
tocStore.contents.root[4].branch[3] = new tocItem("ss_38","",0,0);
tocStore.contents.root[4].branch[4] = new tocItem("ss_39","",0,0);

tocStore.contents.root[5] = new tocItem("ss_40","",0,0);

tocStore.contents.root[5].branch = new Array();

tocStore.contents.root[5].branch[1] = new tocItem("ss_41","",0,0);
tocStore.contents.root[5].branch[2] = new tocItem("ss_42","",0,0);
tocStore.contents.root[5].branch[3] = new tocItem("ss_43","",0,0);
tocStore.contents.root[5].branch[4] = new tocItem("ss_44","",0,0);
tocStore.contents.root[5].branch[5] = new tocItem("ss_45","",0,0);
tocStore.contents.root[5].branch[6] = new tocItem("ss_46","",0,0);
tocStore.contents.root[5].branch[7] = new tocItem("ss_47","",0,0);
tocStore.contents.root[5].branch[8] = new tocItem("ss_48","",0,0);
tocStore.contents.root[5].branch[9] = new tocItem("ss_49","",0,0);
tocStore.contents.root[5].branch[10] = new tocItem("ss_50","",0,0);
tocStore.contents.root[5].branch[11] = new tocItem("ss_51","",0,0);

tocStore.contents.root[6] = new tocItem("ss_52","",0,0);

tocStore.contents.root[6].branch = new Array();

tocStore.contents.root[6].branch[1] = new tocItem("ss_53","",0,0);
tocStore.contents.root[6].branch[2] = new tocItem("ss_54","",0,0);
tocStore.contents.root[6].branch[3] = new tocItem("ss_55","",0,0);
tocStore.contents.root[6].branch[4] = new tocItem("ss_56","",0,0);
tocStore.contents.root[6].branch[5] = new tocItem("ss_57","",0,0);
tocStore.contents.root[6].branch[6] = new tocItem("ss_58","",0,0);
tocStore.contents.root[6].branch[7] = new tocItem("ss_59","",0,0);
tocStore.contents.root[6].branch[8] = new tocItem("ss_60","",0,0);
tocStore.contents.root[6].branch[9] = new tocItem("ss_61","",0,0);
tocStore.contents.root[6].branch[10] = new tocItem("ss_62","",0,0);
tocStore.contents.root[6].branch[11] = new tocItem("ss_63","",0,0);
tocStore.contents.root[6].branch[12] = new tocItem("ss_64","",0,0);
tocStore.contents.root[6].branch[13] = new tocItem("ss_65","",0,0);
tocStore.contents.root[6].branch[14] = new tocItem("ss_66","",0,0);
tocStore.contents.root[6].branch[15] = new tocItem("ss_67","",0,0);

tocStore.contents.root[7] = new tocItem("ss_68","",0,0);

tocStore.contents.root[7].branch = new Array();

tocStore.contents.root[7].branch[1] = new tocItem("ss_69","",0,0);
tocStore.contents.root[7].branch[2] = new tocItem("ss_70","",0,0);
tocStore.contents.root[7].branch[3] = new tocItem("ss_71","",0,0);
tocStore.contents.root[7].branch[4] = new tocItem("ss_72","",0,0);
tocStore.contents.root[7].branch[5] = new tocItem("ss_73","",0,0);
tocStore.contents.root[7].branch[6] = new tocItem("ss_74","",0,0);
tocStore.contents.root[7].branch[7] = new tocItem("ss_75","",0,0);
tocStore.contents.root[7].branch[8] = new tocItem("ss_76","",0,0);
tocStore.contents.root[7].branch[9] = new tocItem("ss_77","",0,0);
tocStore.contents.root[7].branch[10] = new tocItem("ss_78","",0,0);
tocStore.contents.root[7].branch[11] = new tocItem("ss_79","",0,0);
tocStore.contents.root[7].branch[12] = new tocItem("ss_80","",0,0);
tocStore.contents.root[7].branch[13] = new tocItem("ss_81","",0,0);
tocStore.contents.root[7].branch[14] = new tocItem("ss_82","",0,0);
tocStore.contents.root[7].branch[15] = new tocItem("ss_83","",0,0);
tocStore.contents.root[7].branch[16] = new tocItem("ss_84","",0,0);
tocStore.contents.root[7].branch[17] = new tocItem("ss_85","",0,0);
tocStore.contents.root[7].branch[18] = new tocItem("ss_86","",0,0);
tocStore.contents.root[7].branch[19] = new tocItem("ss_87","",0,0);

tocStore.contents.root[8] = new tocItem("ss_88","",0,0);

tocStore.contents.root[8].branch = new Array();

tocStore.contents.root[8].branch[1] = new tocItem("ss_89","",0,0);
tocStore.contents.root[8].branch[2] = new tocItem("ss_90","",0,0);
tocStore.contents.root[8].branch[3] = new tocItem("ss_91","",0,0);
tocStore.contents.root[8].branch[4] = new tocItem("ss_92","",0,0);
tocStore.contents.root[8].branch[5] = new tocItem("ss_93","",0,0);
tocStore.contents.root[8].branch[6] = new tocItem("ss_94","",0,0);
tocStore.contents.root[8].branch[7] = new tocItem("ss_95","",0,0);
tocStore.contents.root[8].branch[8] = new tocItem("ss_96","",0,0);
tocStore.contents.root[8].branch[9] = new tocItem("ss_97","",0,0);
tocStore.contents.root[8].branch[10] = new tocItem("ss_98","",0,0);
tocStore.contents.root[8].branch[11] = new tocItem("ss_99","",0,0);
tocStore.contents.root[8].branch[12] = new tocItem("ss_100","",0,0);
tocStore.contents.root[8].branch[13] = new tocItem("ss_101","",0,0);
tocStore.contents.root[8].branch[14] = new tocItem("ss_102","",0,0);
tocStore.contents.root[8].branch[15] = new tocItem("ss_103","",0,0);
tocStore.contents.root[8].branch[16] = new tocItem("ss_104","",0,0);
tocStore.contents.root[8].branch[17] = new tocItem("ss_105","",0,0);

tocStore.contents.root[9] = new tocItem("ss_106","",0,0);

tocStore.contents.root[9].branch = new Array();

tocStore.contents.root[9].branch[1] = new tocItem("ss_107","",0,0);
tocStore.contents.root[9].branch[2] = new tocItem("ss_108","",0,0);
tocStore.contents.root[9].branch[3] = new tocItem("ss_109","",0,0);
tocStore.contents.root[9].branch[4] = new tocItem("ss_110","",0,0);
tocStore.contents.root[9].branch[5] = new tocItem("ss_111","",0,0);
tocStore.contents.root[9].branch[6] = new tocItem("ss_112","",0,0);
tocStore.contents.root[9].branch[7] = new tocItem("ss_113","",0,0);
tocStore.contents.root[9].branch[8] = new tocItem("ss_114","",0,0);
tocStore.contents.root[9].branch[9] = new tocItem("ss_115","",0,0);

tocStore.contents.root[10] = new tocItem("ss_116","",0,0);

tocStore.contents.root[10].branch = new Array();

tocStore.contents.root[10].branch[1] = new tocItem("ss_117","",0,0);
tocStore.contents.root[10].branch[2] = new tocItem("ss_118","",0,0);
tocStore.contents.root[10].branch[3] = new tocItem("ss_119","",0,0);
tocStore.contents.root[10].branch[4] = new tocItem("ss_120","",0,0);
tocStore.contents.root[10].branch[5] = new tocItem("ss_121","",0,0);
tocStore.contents.root[10].branch[6] = new tocItem("ss_122","",0,0);
tocStore.contents.root[10].branch[7] = new tocItem("ss_123","",0,0);
tocStore.contents.root[10].branch[8] = new tocItem("ss_124","",0,0);
tocStore.contents.root[10].branch[9] = new tocItem("ss_125","",0,0);
tocStore.contents.root[10].branch[10] = new tocItem("ss_126","",0,0);
tocStore.contents.root[10].branch[11] = new tocItem("ss_127","",0,0);
tocStore.contents.root[10].branch[12] = new tocItem("ss_128","",0,0);
tocStore.contents.root[10].branch[13] = new tocItem("ss_129","",0,0);

tocStore.contents.root[11] = new tocItem("ss_130","",0,0);

tocStore.contents.root[11].branch = new Array();

tocStore.contents.root[11].branch[1] = new tocItem("ss_131","",0,0);
tocStore.contents.root[11].branch[2] = new tocItem("ss_132","",0,0);
tocStore.contents.root[11].branch[3] = new tocItem("ss_133","",0,0);

tocStore.contents.root[12] = new tocItem("ss_134","",0,0);

tocStore.contents.root[12].branch = new Array();

tocStore.contents.root[12].branch[1] = new tocItem("ss_135","",0,0);
tocStore.contents.root[12].branch[2] = new tocItem("ss_136","",0,0);
tocStore.contents.root[12].branch[3] = new tocItem("ss_137","",0,0);
tocStore.contents.root[12].branch[4] = new tocItem("ss_138","",0,0);
tocStore.contents.root[12].branch[5] = new tocItem("ss_139","",0,0);

tocStore.contents.root[13] = new tocItem("ss_140","",0,0);

tocStore.contents.root[13].branch = new Array();

tocStore.contents.root[13].branch[1] = new tocItem("ss_141","",0,0);
tocStore.contents.root[13].branch[2] = new tocItem("ss_142","",0,0);

tocStore.contents.root[14] = new tocItem("ss_143","",0,0);

tocStore.contents.root[14].branch = new Array();

tocStore.contents.root[14].branch[1] = new tocItem("ss_144","",0,0);
tocStore.contents.root[14].branch[2] = new tocItem("ss_145","",0,0);

tocStore.contents.root[15] = new tocItem("ss_146","",0,0);

tocStore.contents.root[15].branch = new Array();

tocStore.contents.root[15].branch[1] = new tocItem("ss_147","",0,0);
tocStore.contents.root[15].branch[2] = new tocItem("ss_148","",0,0);

tocStore.contents.root[16] = new tocItem("ss_149","",0,0);

tocStore.contents.root[16].branch = new Array();

tocStore.contents.root[16].branch[1] = new tocItem("ss_150","",0,0);
tocStore.contents.root[16].branch[2] = new tocItem("ss_151","",0,0);
tocStore.contents.root[16].branch[3] = new tocItem("ss_152","",0,0);
tocStore.contents.root[16].branch[4] = new tocItem("ss_153","",0,0);
tocStore.contents.root[16].branch[5] = new tocItem("ss_154","",0,0);
tocStore.contents.root[16].branch[6] = new tocItem("ss_155","",0,0);
tocStore.contents.root[16].branch[7] = new tocItem("ss_156","",0,0);

tocStore.contents.root[17] = new tocItem("ss_157","",0,0);

tocStore.contents.root[17].branch = new Array();

tocStore.contents.root[17].branch[1] = new tocItem("ss_158","",0,0);
tocStore.contents.root[17].branch[2] = new tocItem("ss_159","",0,0);

tocStore.contents.root[18] = new tocItem("ss_160","",0,0);

tocStore.contents.root[19] = new tocItem("ss_161","",0,0);

tocStore.contents.root[20] = new tocItem("ss_162","",0,0);

tocStore.contents.root[21] = new tocItem("ss_163","",0,0);

tocStore.contents.root[22] = new tocItem("ss_164","",0,0);

tocStore.contents.root[23] = new tocItem("","",0,0);

tocStore.contents.root[23].branch = new Array();

tocStore.contents.root[23].branch[1] = new tocItem("ss_9","gr000002",0,0);
tocStore.contents.root[23].branch[2] = new tocItem("ss_11","gr000003",0,0);
tocStore.contents.root[23].branch[3] = new tocItem("ss_14","gr000004",0,0);
tocStore.contents.root[23].branch[4] = new tocItem("ss_18","gr000005",0,0);
tocStore.contents.root[23].branch[5] = new tocItem("ss_37","gr000006",0,0);
tocStore.contents.root[23].branch[6] = new tocItem("ss_37","gr000007",0,0);
tocStore.contents.root[23].branch[7] = new tocItem("ss_41","gr000008",0,0);
tocStore.contents.root[23].branch[8] = new tocItem("ss_41","gr000009",0,0);
tocStore.contents.root[23].branch[9] = new tocItem("ss_41","gr000064",0,0);
tocStore.contents.root[23].branch[10] = new tocItem("ss_41","gr000065",0,0);
tocStore.contents.root[23].branch[11] = new tocItem("ss_41","gr000066",0,0);
tocStore.contents.root[23].branch[12] = new tocItem("ss_41","gr000010",0,0);
tocStore.contents.root[23].branch[13] = new tocItem("ss_42","gr000011",0,0);
tocStore.contents.root[23].branch[14] = new tocItem("ss_42","gr000012",0,0);
tocStore.contents.root[23].branch[15] = new tocItem("ss_42","gr000013",0,0);
tocStore.contents.root[23].branch[16] = new tocItem("ss_43","gr000014",0,0);
tocStore.contents.root[23].branch[17] = new tocItem("ss_49","gr000015",0,0);
tocStore.contents.root[23].branch[18] = new tocItem("ss_54","gr000016",0,0);
tocStore.contents.root[23].branch[19] = new tocItem("ss_55","gr000017",0,0);
tocStore.contents.root[23].branch[20] = new tocItem("ss_55","gr000018",0,0);
tocStore.contents.root[23].branch[21] = new tocItem("ss_55","gr000019",0,0);
tocStore.contents.root[23].branch[22] = new tocItem("ss_55","gr000020",0,0);
tocStore.contents.root[23].branch[23] = new tocItem("ss_74","gr000023",0,0);
tocStore.contents.root[23].branch[24] = new tocItem("ss_74","gr000024",0,0);
tocStore.contents.root[23].branch[25] = new tocItem("ss_75","gr000025",0,0);
tocStore.contents.root[23].branch[26] = new tocItem("ss_75","gr000026",0,0);
tocStore.contents.root[23].branch[27] = new tocItem("ss_87","gr000027",0,0);
tocStore.contents.root[23].branch[28] = new tocItem("ss_91","gr000028",0,0);
tocStore.contents.root[23].branch[29] = new tocItem("ss_93","gr000029",0,0);
tocStore.contents.root[23].branch[30] = new tocItem("ss_94","gr000030",0,0);
tocStore.contents.root[23].branch[31] = new tocItem("ss_94","gr000031",0,0);
tocStore.contents.root[23].branch[32] = new tocItem("ss_94","gr000032",0,0);
tocStore.contents.root[23].branch[33] = new tocItem("ss_94","gr000033",0,0);
tocStore.contents.root[23].branch[34] = new tocItem("ss_94","gr000034",0,0);
tocStore.contents.root[23].branch[35] = new tocItem("ss_96","gr000035",0,0);
tocStore.contents.root[23].branch[36] = new tocItem("ss_96","gr000036",0,0);
tocStore.contents.root[23].branch[37] = new tocItem("ss_107","gr000037",0,0);
tocStore.contents.root[23].branch[38] = new tocItem("ss_108","gr000038",0,0);
tocStore.contents.root[23].branch[39] = new tocItem("ss_109","gr000039",0,0);
tocStore.contents.root[23].branch[40] = new tocItem("ss_109","gr000040",0,0);
tocStore.contents.root[23].branch[41] = new tocItem("ss_109","gr000041",0,0);
tocStore.contents.root[23].branch[42] = new tocItem("ss_111","gr000042",0,0);
tocStore.contents.root[23].branch[43] = new tocItem("ss_115","gr000043",0,0);
tocStore.contents.root[23].branch[44] = new tocItem("ss_115","gr000044",0,0);
tocStore.contents.root[23].branch[45] = new tocItem("ss_118","gr000045",0,0);
tocStore.contents.root[23].branch[46] = new tocItem("ss_119","gr000046",0,0);
tocStore.contents.root[23].branch[47] = new tocItem("ss_119","gr000047",0,0);
tocStore.contents.root[23].branch[48] = new tocItem("ss_121","gr000048",0,0);
tocStore.contents.root[23].branch[49] = new tocItem("ss_122","gr000049",0,0);
tocStore.contents.root[23].branch[50] = new tocItem("ss_122","gr000050",0,0);
tocStore.contents.root[23].branch[51] = new tocItem("ss_125","gr000051",0,0);
tocStore.contents.root[23].branch[52] = new tocItem("ss_125","gr000052",0,0);
tocStore.contents.root[23].branch[53] = new tocItem("ss_125","gr000053",0,0);
tocStore.contents.root[23].branch[54] = new tocItem("ss_126","gr000054",0,0);
tocStore.contents.root[23].branch[55] = new tocItem("ss_126","gr000055",0,0);
tocStore.contents.root[23].branch[56] = new tocItem("ss_147","gr000056",0,0);
tocStore.contents.root[23].branch[57] = new tocItem("ss_147","gr000057",0,0);
tocStore.contents.root[23].branch[58] = new tocItem("ss_148","gr000058",0,0);
tocStore.contents.root[23].branch[59] = new tocItem("ss_148","gr000059",0,0);
tocStore.contents.root[23].branch[60] = new tocItem("ss_158","gr000060",0,0);
tocStore.contents.root[23].branch[61] = new tocItem("ss_158","gr000061",0,0);
tocStore.contents.root[23].branch[62] = new tocItem("ss_159","gr000062",0,0);

tocStore.contents.root[24] = new tocItem("","",0,0);

tocStore.contents.root[24].branch = new Array();

tocStore.contents.root[24].branch[1] = new tocItem("ss_121","gr000071",0,0);

}

// EOF
