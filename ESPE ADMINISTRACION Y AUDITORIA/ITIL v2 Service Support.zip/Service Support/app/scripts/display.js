// display object
// CD Framework 1.1 Module
// Rupert Davies - 2001-11-21
// Customised for PRINCE2 v.2.0
// (c) 2002 TSO

// *** Objects ***

var display = new Object();


// *** Properties ***

display.searchResultsPerPage = 20;
display.searchPage = 0;
display.highlightWords = "";
display.highlightNavigation = true;
display.highlightNavBack = "";
display.highlightNavNext = "";
display.highlightTagBefore = "";
display.highlightTagAfter = "";
display.highlightPageURL = "";
display.inHl0 = false;
display.previousTocHighlight = "";


// *** Methods ***

function displayInit() {
this.highlightNavNext = "<img src=\"" + envRoot + "/chrome/highnext.gif\" border=\"0\" hspace=\"4\" alt=\"Jump to next highlight\">";
this.highlightNavBack = "<img src=\"" + envRoot + "/chrome/highprev.gif\" border=\"0\" hspace=\"4\" alt=\"Jump to previous highlight\">";
this.highlightTagBefore = "<span style=\"background-color:#99CCFF\"><b>";
this.highlightTagAfter = "</b></span>";
}
display.init = displayInit;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 



function displayUpdateButtons() {

if (ui.enableShowHide) {
	top.frames['menubar'].buttShowHide.stateChange('active');
	}
else {
	top.frames['menubar'].buttShowHide.stateChange('disabled');
	}
/*
if (ui.enablePrev) {
	top.frames['menubar'].buttPrev.stateChange('active');
	}
else {
	top.frames['menubar'].buttPrev.stateChange('disabled');
	}
if (ui.enableNext) {
	top.frames['menubar'].buttNext.stateChange('active');
	}
else {
	top.frames['menubar'].buttNext.stateChange('disabled');
	}
*/
this.updateBookmarkFlag();
}
display.updateButtons = displayUpdateButtons;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displaySearchResults(pageNo) {
//if (search.phrase) {
//	ui.enableHighlight = false;
//	}
//else {
//	ui.enableHighlight = true;
//	}
var resultsPerPage = this.searchResultsPerPage;
if ((pageNo=="" || pageNo==null) && pageNo!=0) {
	pageNo = this.searchPage;
	}
else {
	this.searchPage = pageNo;
	}
var resultsHtml = "";
resultHtml = "<html><head><style type='text/css'>\nbody {  font-family: Verdana, Arial, Helvetica, sans-serif; color: #000000; background-color: #EEEEEE}\ntd {  font-size: 0.8em; font-family: Verdana, Arial, Helvetica, sans-serif}\na:hover {  color: #0000CC; text-decoration: underline}\na {  color: #000066; text-decoration: none}\nth {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 0.8em; font-weight: bold}\na:visited {  color: #000066}</style></head><body>\n";

if (search.resultSet[0] < 1) {
	resultHtml += "<h4><u>Nothing Found</u></h4><i>Please try a new search</i>";
	}

else {
	var noResults = search.resultSet[0];
	var startResult = (resultsPerPage * pageNo) + 1;
	var endResult = startResult + resultsPerPage - 1;
	if (noResults > search.maxHits) noResults = search.maxHits;
	if (endResult > noResults) endResult = noResults;
	resultHtml += "<table width='100%' border='0'><tr><td><hr noshade='noshade' size='1'><b>Search for: " + search.lastQuery + "</b><hr noshade='noshade' size='1'></td></tr></table>";
	resultHtml += "<table width='100%' border='0'><tr><td><b>" + startResult + " - " + endResult + " of " + noResults + " results:</b></td><td align='right' valign='top'>";

// Back and Next links
	if (pageNo > 0) {
		resultHtml += "<a href='javascript:top.scripts.display.searchResults(" + (pageNo - 1) + ")'><img src='chrome/srch_prev.gif' border='0' alt='Previous Results Page'></a>";
		}
	if (endResult < noResults) {
		resultHtml += "&nbsp;<a href='javascript:top.scripts.display.searchResults(" + (pageNo + 1) + ")'><img src='chrome/srch_next.gif' border='0' alt='Next Results Page'></a>";
		}
	resultHtml += "</td></tr></table><table width='100%' border='0'>";

// Main search results
	var i=0;
	for (i=startResult ; i<=endResult; i++) {
		if (ui.enableHighlight) {
			resultHtml += "<tr valign='top'><td>" + i + ". </td><td><a href=\"javascript:top.scripts.display.loadHighlight('" + search.resultSet[i].location + "', '" + search.keywords + "');\">" + search.resultSet[i].title + "</a></td><td><i>(" + search.resultSet[i].relevance + "%)</i></td></tr>";
			}
		else {
			resultHtml += "<tr valign='top'><td>" + i + ". </td><td><a href=\"javascript:top.scripts.display.page('" + search.resultSet[i].location+"')\">" + search.resultSet[i].title + "</a></td><td><i>(" + search.resultSet[i].relevance + "%)</i></td></tr>";
			}
		}
	resultHtml += "</table><table width='100%'><td align='right' valign='top'>";

// Back and Next links again
	if (pageNo > 0) {
		resultHtml += "&nbsp;<a href='javascript:top.scripts.display.searchResults(" + (pageNo - 1) + ")'><img src='chrome/srch_prev.gif' border='0' alt='Previous Results Page'></a>";
		}
	if (endResult < noResults) {
		resultHtml += "&nbsp;<a href='javascript:top.scripts.display.searchResults(" + (pageNo + 1) + ")'><img src='chrome/srch_next.gif' border='0' alt='Next Results Page'></a>";
		}
	resultHtml += "</tr></table>";
	}

resultHtml += "</body></html>";

top.frames['main'].frames['navPane'].document.open();
top.frames['main'].frames['navPane'].document.write(resultHtml);
top.frames['main'].frames['navPane'].document.close();
}
display.searchResults = displaySearchResults;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function relevanceImage(score) {
var strHtmlCode = "";
if (score<=5) {
	strHtmlCode = "<img src='chrome/rel05.gif' alt='Relevance: " + score + "%' />";
	}
if (score>5 && score<=15) {
	strHtmlCode = "<img src='chrome/rel15.gif' alt='Relevance: " + score + "%' />";
	}
if (score>15 && score<=25) {
	strHtmlCode = "<img src='chrome/rel25.gif' alt='Relevance: " + score + "%' />";
	}
if (score>25 && score<=35) {
	strHtmlCode = "<img src='chrome/rel35.gif' alt='Relevance: " + score + "%' />";
	}
if (score>35 && score<=45) {
	strHtmlCode = "<img src='chrome/rel45.gif' alt='Relevance: " + score + "%' />";
	}
if (score>45 && score<=55) {
	strHtmlCode = "<img src='chrome/rel55.gif' alt='Relevance: " + score + "%' />";
	}
if (score>55 && score<=65) {
	strHtmlCode = "<img src='chrome/rel65.gif' alt='Relevance: " + score + "%' />";
	}
if (score>65 && score<=75) {
	strHtmlCode = "<img src='chrome/rel75.gif' alt='Relevance: " + score + "%' />";
	}
if (score>75 && score<=85) {
	strHtmlCode = "<img src='chrome/rel85.gif' alt='Relevance: " + score + "%' />";
	}
if (score>85 && score<=95) {
	strHtmlCode = "<img src='chrome/rel95.gif' alt='Relevance: " + score + "%' />";
	}
if (score>95) {
	strHtmlCode = "<img src='chrome/rel100.gif' alt='Relevance: " + score + "%' />";
	}
return strHtmlCode;
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayPage(url) {
if (top.frames['main'].frames['navPane']) {
	top.frames['main'].frames['content'].location = url;
	}
else {
	top.frames['main'].location = url;
	}
}
display.page = displayPage;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayTitle(title) {
var strHtml = "<table cellspacing='0' cellpadding='0' border='0' align='center'><tr><td class\"title\"><font face='Tahoma, Verdana, Arial, Helvetica, sans-serif' size='2' color='#333333'>" + title + "</font></td></tr></table>";
if (top.scripts.DOM) {
	top.frames['title'].document.getElementById('title').innerHTML = strHtml;
	}
if (top.scripts.IE) {
	top.frames['title'].title.innerHTML = strHtml;
	}

if (top.scripts.NS) {
	top.frames['title'].document.title.document.open();
	top.frames['title'].document.title.document.write(strHtml);
	top.frames['title'].document.title.document.close();
	}
}
display.title = displayTitle;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


// Highlight page title in Toc by reference to div id which is same as page id
function displayHighlightToc() {
var prevElm = "";
var currentElm = "";
if (top.scripts.DOM) {
	if (top.frames['main'].frames['navPane'] &&top.frames['main'].frames['navPane'].document.getElementById(top.scripts.currentPageId)) {
		if (this.previousTocHighlight!="" && top.frames['main'].frames['navPane'].document.getElementById(this.previousTocHighlight)) {
			top.frames['main'].frames['navPane'].document.getElementById(this.previousTocHighlight).className = "noHighlight";
			}
		currentElm = top.frames['main'].frames['navPane'].document.getElementById(top.scripts.currentPageId);
		currentElm.className = "highlight";
		}
	this.previousTocHighlight = top.scripts.currentPageId;
	}
if (top.scripts.IE) {
	if (top.frames['main'].frames['navPane'] && top.frames['main'].frames['navPane'].document.all[top.scripts.currentPageId]) {
		if (this.previousTocHighlight!="" && top.frames['main'].frames['navPane'].document.all[this.previousTocHighlight]) {
			top.frames['main'].frames['navPane'].document.all[this.previousTocHighlight].style.color = 'black';
			}
		top.frames['main'].frames['navPane'].document.all[top.scripts.currentPageId].style.color = 'red';
		}
	this.previousTocHighlight = top.scripts.currentPageId;
	}
if (top.scripts.NS) {
// no solution yet... (not likely to bother either)
	}
}
display.highlightToc = displayHighlightToc;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayUpdateContent() {
if (top.frames['main'].frames['navPane']) {
	top.frames['main'].frames['content'].location = envRoot + "/cont_loader.htm";
	}
else {
	top.frames['main'].location = envRoot + "/cont_loader.htm";
	}
}
display.updateContent = displayUpdateContent
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayShowNavPane() {
if (top.frames['main'].frames['navPane']) {
	top.frames['main'].frames['navPane'].location = envRoot + "/nav_loader.htm";
	}
else {
	top.frames['main'].location = envRoot + "/nav_frame.htm";
	}
}
display.showNavPane = displayShowNavPane;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayShowContentFull() {
top.frames['main'].location = "cont_loader.htm";
}
display.showContentFull = displayShowContentFull;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayAlert(message) {
alert(message);
}
display.alert = displayAlert;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayHighlightPage(url, keywords) {
var highlightApp = top.applets.document.highlight;
highlightApp.setScrollToAnchorFn("top.scripts.display.scrollTo");
highlightApp.setHighlightingTags(this.highlightTagBefore, this.highlightTagAfter);
highlightApp.setNavigationButtons(this.highlightNavBack, this.highlightNavNext);
//if (top.scripts.NS) {
//	highlightApp.setUseCallbacks(true);
//	}
//else {
//	highlightApp.setUseCallbacks(false);
//	}
// var encrypted = false;
// if (top.scripts.IE4early || top.scripts.IE5_5 || top.scripts.IE6) {
//	this.highlightNavigation = false;
//	}
// url = envRoot + "/" + url;
// alert("Highlight URL: "+url);
var docRef = highlightApp.openDocument(url, keywords, this.highlightNavigation);
var tempPage = "";
while (true) {
	var page = highlightApp.readPage(docRef);
	if (page == null) {
		break;
		}
	if (page.length == 0) {
		break;
		}
	tempPage = tempPage + page;
	if (tempPage.length == 0) {
		break;
		}
	}
if (tempPage.length > 0) {
	if (top.frames['main'].frames['navPane']) {
		top.frames['main'].frames['content'].document.open();
		top.frames['main'].frames['content'].document.write(tempPage);
		top.frames['main'].frames['content'].document.close();
		}
	else {
		top.frames['main'].document.open();
		top.frames['main'].document.write(tempPage);
		top.frames['main'].document.close();
		}
	}
else {
	display.alert("Parsing Error.\nThis document will be displayed without highlighting.");
	if (top.frames['main'].frames['navPane']) {
		top.frames['main'].frames['content'].location = url;
		}
	else {
		top.frames['main'].location = url;
		}
	}
}
display.highlightPage = displayHighlightPage;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayHighlightSwitch(bln) {
this.inHl0 = bln;
this.highlightPage(this.highlightPageURL,this.highlightWords);
}
display.highlightSwitch = displayHighlightSwitch;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayLoadHighlight(url, keywords) {
if (keywords == null || keywords == "" || keywords == " ") {
	this.page(url);
	}
else {
	this.highlightPageURL = url;
	this.highlightWords = keywords;
	var locationStr = "";
	if (this.inHl0) {
		locationStr = top.scripts.envRoot + "/wr_hl1.htm";
		}
	else {
		locationStr = top.scripts.envRoot + "/wr_hl0.htm";
		}
	if (top.scripts.ui.enableHighlight && this.highlightWords != "") {
		locationStr = locationStr + "#qa_anchor_1";
		}
	if (top.frames['main'].frames['navPane']) {
		top.frames['main'].frames['content'].location = locationStr;
		}
	else {
		top.frames['main'].location = locationStr;
		}
	}
}
display.loadHighlight = displayLoadHighlight;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayHistory() {
var strHtml="<html><head><title>User History</title><style type='text/css'>\nbody {  font-family: Tahoma, Verdana, Arial, Helvetica, sans-serif; color: #000000; background-color: #EEEEEE}\ntd {  font-size: 0.85em; font-family: Tahoma, Verdana, Arial, Helvetica, sans-serif}\na:hover {  color: #0000CC; text-decoration: underline}\na {  color: #000066; text-decoration: none}\na:visited {  color: #000066}\nh2 { font-size: 0.9em;}\n</style></head><body><h2>History of pages viewed</h2><table width='100%' border='0'>";
if (viewHistory.queue[0].pageId == "none") {
	strHtml = strHtml + "<tr><td>No entries</td></tr>";
	}
else {
	var start = viewHistory.currentIndex;
	var pos = start;
	var count = 0;
	while(pos >= 0) {
		if (viewHistory.queue[pos].pageId == "none") { break; }
		count++;
		strHtml = strHtml + "<tr><td valign='top'>" + count + ". " + "</td><td><a href='" + envRoot + "/content/" + viewHistory.queue[pos].href + "' target='content'>" + viewHistory.queue[pos].title + "</a></td></tr>";
		pos--;
		}
	pos = viewHistory.maxEntries -1;
	while(pos > start) {
		if (viewHistory.queue[pos].pageId == "none") { break; }
		count++;
		strHtml = strHtml + "<tr><td valign='top'>" + count + ". " + "</td><td><a href='" + envRoot + "/content/" + viewHistory.queue[pos].href + "' target='content'>" + viewHistory.queue[pos].title + "</a></td></tr>";
		pos--;
		}
	}
strHtml = strHtml + "</table></body></html>";
top.frames['main'].frames['navPane'].document.open();
top.frames['main'].frames['navPane'].document.write(strHtml);
top.frames['main'].frames['navPane'].document.close();
}
display.history = displayHistory;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayUpdateBookmarkFlag(pageId) {
if (!ui.enableToggleBookmark) {
	top.frames['title'].buttFlag.stateChange("disabled");
	}
else if (bookmarks.check(pageId)) {
	this.bookmarkOn();
	}
else {
	this.bookmarkOff();
	}
}
display.updateBookmarkFlag = displayUpdateBookmarkFlag;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayBookmarkOn() {
top.frames['title'].buttFlag.stateChange("highlight");
/*
strHtml = "<a href='javascript:top.scripts.ui.toggleBookmark();'><img src='chrome/flag_on.gif' alt='Toggle Bookmark' border='0' /></a>";
if (NS) {
	top.frames['title'].document.flag.document.open();
	top.frames['title'].document.flag.document.write(strHtml);
	top.frames['title'].document.flag.document.close();
	}
else if (top.frames['title'].document.flagImage) {
	top.frames['title'].document.flagImage.src = "chrome/flag_on.gif";
	}
*/
/*
if (IE) {
	top.frames['title'].flag.innerHTML = strHtml;
	}
if (NS) {
	top.frames['title'].document.flag.document.open();
	top.frames['title'].document.flag.document.write(strHtml);
	top.frames['title'].document.flag.document.close();
	}
if (DOM) {
	top.frames['title'].document.getElementById('flag').innerHTML = strHtml;
	}
*/
}
display.bookmarkOn = displayBookmarkOn;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayBookmarkOff() {
top.frames['title'].buttFlag.stateChange("active");
/*
strHtml = "<a href='javascript:top.scripts.ui.toggleBookmark();'><img src='chrome/flag_off.gif' alt='Toggle Bookmark' border='0' /></a>";
if (NS) {
	top.frames['title'].document.flag.document.open();
	top.frames['title'].document.flag.document.write(strHtml);
	top.frames['title'].document.flag.document.close();
	}
else if (top.frames['title'].document.flagImage) {
	top.frames['title'].document.flagImage.src = "chrome/flag_off.gif";
	}
*/
/*
if (IE) {
	top.frames['title'].flag.innerHTML = strHtml;
	}
if (NS) {
	top.frames['title'].document.flag.document.open();
	top.frames['title'].document.flag.document.write(strHtml);
	top.frames['title'].document.flag.document.close();
	}
if (DOM) {
	top.frames['title'].document.getElementById('flag').innerHTML = strHtml;
	}
*/
}
display.bookmarkOff = displayBookmarkOff;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayBookmarks() {
var strHtml = "<html><head><title>Bookmarks</title><style type='text/css'>\nbody {  font-family: Tahoma, Verdana, Arial, Helvetica, sans-serif; color: #000000; background-color: #EEEEEE}\ntd {  font-size: 0.85em; font-family: Tahoma, Verdana, Arial, Helvetica, sans-serif}\na:hover {  color: #0000CC; text-decoration: underline}\na {  color: #000066; text-decoration: none}\na:visited {  color: #000066}\nh2 { font-size: 0.9em;}\n</style></head><body><h2>Bookmarked pages</h2><table width='100%' border='0'>";
var count = 0;
for (var obj in bookmarks.store) {
	if (bookmarks.store[obj] != null) {
		count++;
		var pageId = obj;
		var title = top.scripts.bookmarks.store[obj].title;
		var href = top.scripts.bookmarks.store[obj].href;
		strHtml = strHtml + "<tr><td valign=\"top\"><a href=\"javascript:top.scripts.ui.clearBookmark('" + pageId + "');\"><img src=\"" + envRoot + "/chrome/clear.gif\" alt=\"Clear Bookmark\" border=\"0\"></a></td>";
		strHtml = strHtml + "<td valign=\"top\">" + count + ". </td><td><a href=\"" + envRoot + "/content/" + href + "\" target=\"content\">" + title + "</a></td></tr>";
		}
	}
if (count == 0) {
	strHtml = strHtml + "<tr><td><p><i>No documents bookmarked</i></p><p>To add a bookmark to a page, click on the flag icon above. A bookmarked page will display a red flag next to the page title. Click the flag icon again to clear a bookmark.</p></td></tr>";
	}
strHtml = strHtml + "</table></body></html>";
top.frames['main'].frames['navPane'].document.open();
top.frames['main'].frames['navPane'].document.write(strHtml);
top.frames['main'].frames['navPane'].document.close();
}
display.bookmarks = displayBookmarks;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function displayScrollTo(name, doc) {
if (navigator.userAgent.toLowerCase().indexOf("msie") != -1) {
	var namedAnchor = doc.anchors.item(name);
	if (namedAnchor != null) {
		doc.anchors.item(name).scrollIntoView();
		}
	}
else {
	doc.location.hash = name;
	}
}
display.scrollTo = displayScrollTo;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

// EOF