// session object
// CD Framework 1.1  Module
// Rupert Davies - 2001-11-21
// (c) 2001 TSO

// *** Objects ***

var session = new Object();
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// *** Properties ***
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// *** Methods ***

function sessionLoad() {
if(document.cookie != "") {
	var strCookie = document.cookie;
	var cookieVersion = "";
	var cookieContent = "";
	var strBookmarks = "";
	var cookieItem = strCookie.split("; ");
	for (i=0; i<cookieItem.length; i++) {
		var ident = cookieItem[i].split("=")[0];
		var content = cookieItem[i].split("=")[1];
		if (ident == appName) {
			cookieContent = content;
			}
		}
	if (cookieContent != "") {
		var field = cookieContent.split("&");
		for  (i=0; i<field.length; i++) {
			var fieldName = field[i].split(":")[0];
			var fieldValue = field[i].split(":")[1];
			if (fieldName == "version") {
				cookieVersion = fieldValue;
				}
			if (fieldName == "bookmarks") {
				strBookmarks = fieldValue;
				}
			}
		if (cookieVersion != appVersion) {
			// Version mis-match, so delete cookie
			document.cookie = appName + "=; expires=Thu, 01-Jan-70 00:00:01 GMT";
			}
		else {
			top.scripts.bookmarks.deserialise(strBookmarks);
			}
		}
	}
}
session.load = sessionLoad;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


function sessionSave() {
var expireDate = new Date;
expireDate.setMonth(expireDate.getMonth()+12);
var strCookie = appName + "=";
strCookie = strCookie + "version:" + appVersion;
strCookie = strCookie + "&bookmarks:" + top.scripts.bookmarks.serialise();
strCookie = strCookie + "; expires=" + expireDate.toGMTString();
document.cookie = strCookie;
}
session.save = sessionSave;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// EOF