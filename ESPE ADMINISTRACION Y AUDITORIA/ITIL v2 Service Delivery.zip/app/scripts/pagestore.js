// pageStore object
// Version 1.0 - Initial Framework Module - Rupert Davies
// (c) TSO 2001

// *** Objects ***

var pageStore = new Object();

function pageItem(title, href) {
	this.title=title;
	this.href=href;
}


// *** Methods ***

function pageStoreInit() {
initPageStoreData();
}
pageStore.init = pageStoreInit;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function getPageTitle(id) {
var pageTitle = "";
if (this[id]) {
	if (this[id].title) {
		pageTitle = this[id].title;
		}
	}
return (pageTitle);
}
pageStore.getTitle = getPageTitle;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function getPageHref(id) {
var pageHref = "";
if (this[id]) {
	if (this[id].href) {
		pageHref = this[id].href;
		}
	}
return (pageHref);
}
pageStore.getHref = getPageHref;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function pageExists(id) {
if (this[id]) {
	return true;
	}
else {
	return false;
	}
}
pageStore.exists = pageExists;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

// EOF