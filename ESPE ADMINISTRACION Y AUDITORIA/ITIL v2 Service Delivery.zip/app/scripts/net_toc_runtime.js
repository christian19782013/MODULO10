// Netscape ToC Runtime Functions
// Version 1.0 - Rupert Davies
// (c) 2001 TSO


function netStart(tocId) {
if (tocId=="" || tocId==null) {
	tocId = top.scripts.tocStore.currentToc;
	}
var doc = document.layers["container"].document;
var plus = new Image();
plus.src = "../images/plus.gif";
var minus = new Image();
minus.src = "../images/minus.gif";

var lyrs = doc.layers.length;
for (i=0; i<lyrs; i++) {
	doc.layers[i].visibility = 'hide';
	}
var measure = 0;
var lgt = top.scripts.tocStore[tocId].root.length;
for (i=1; i<lgt; i++) {
	var lyr = "root" + i;
	doc.layers[lyr].moveTo(4,measure);
	doc.layers[lyr].visibility = 'show';
	var hgt = doc.layers[lyr].clip.height;
	measure = measure + hgt + 6;
	var img = "exp" + i;
	if (doc.layers[lyr].document.images[img]) { doc.layers[lyr].document.images[img].src = plus.src }
	if (top.scripts.tocStore[tocId].root[i].branch[1] && top.scripts.tocStore[tocId].root[i].state) {
		doc.layers[lyr].document.images[img].src = minus.src
		var lgt1 = top.scripts.tocStore[tocId].root[i].branch.length;
		var lyr1 = "sub" + i + "a1";
		for (j=1; j<lgt1; j++) {
			var lyr1 = "sub" + i + "a" + j;
			doc.layers[lyr1].moveTo(4,measure);
			doc.layers[lyr1].visibility = 'show';
			var hgt1 = doc.layers[lyr1].clip.height;
			measure = measure+hgt1;
			var img2 = "exp" + i + "a" + j;
			if (doc.layers[lyr1].document.images[img2]) { doc.layers[lyr1].document.images[img2].src = plus.src } 
			if (top.scripts.tocStore[tocId].root[i].branch[j].branch[1] && top.scripts.tocStore[tocId].root[i].branch[j].state) {
				doc.layers[lyr1].document.images[img2].src = minus.src;
				var lgt2 = top.scripts.tocStore[tocId].root[i].branch[j].branch.length;
				var lyr2 = "sub" + i + "a" + j + "a1";
				for (k=1; k<lgt2; k++) {
					var lyr2 = "sub" + i + "a" + j + "a" + k;
					doc.layers[lyr2].moveTo(4,measure);
					doc.layers[lyr2].visibility = 'show';
					var hgt2 = doc.layers[lyr2].clip.height;
					measure = measure + hgt2;
					}
				}
			}
		}
	}
}
