// viewHistory object
// CD Framework 1.2  Module
// Rupert Davies - 2002-06-14
// (c) 2002 TSO

// *** Objects ***

var viewHistory = new Object();
viewHistory.queue = new Array();

function historyItem(pageId, title, href) {
	this.pageId = pageId;
	this.title = title;
	this.href = href;
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// *** Properties ***

viewHistory.currentIndex = 0;
viewHistory.maxEntries = 20;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// *** Methods ***

function historyInit() {
for (i=0; i<this.maxEntries; i++) {
	this.queue[i] = new historyItem("none","","");
	}
this.currentIndex = 0;
}
viewHistory.init = historyInit;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function historyAdd(pageId) {
if (this.queue[0].pageId == "none") {		// if first addition ever
	this.queue[0].pageId = pageId;
	this.queue[0].title = top.scripts.pageStore.getTitle(pageId);
	this.queue[0].href = top.scripts.pageStore.getHref(pageId);
	}
else {
	if ( pageId != this.queue[this.currentIndex].pageId) {
		this.currentIndex++;
		if (this.currentIndex == this.maxEntries) {
			this.currentIndex = 0;
			}
		this.queue[this.currentIndex].pageId = pageId;
		this.queue[this.currentIndex].title = top.scripts.pageStore.getTitle(pageId);
		this.queue[this.currentIndex].href = top.scripts.pageStore.getHref(pageId);
		}
	}
}
viewHistory.add = historyAdd;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function historyFirstPageId() {
var returnId = "";
returnId = this.queue[this.currentIndex].pageId;
if (returnId == "none") {
	returnId = "";
	}
return returnId;
}
viewHistory.firstPageId = historyFirstPageId;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function historySerialise() {
strSerialised = "";
if (this.queue[0].pageId != "none") {
	var start = this.currentIndex;
	var pos = start;
	while(pos >= 0) {
		if (this.queue[pos].pageId == "none") { break; }
		strSerialised = strSerialised + this.queue[pos].pageId + "@";
		pos--;
		}
	pos = this.maxEntries -1;
	while(pos > start) {
		if (this.queue[pos].pageId == "none") { break; }
		count++;
		strSerialised = strSerialised + this.queue[pos].pageId + "@";
		pos--;
		}
	}
return strSerialised;
}
viewHistory.serialise = historySerialise;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


// *** UNTESTED CODE  ***
function historyDeserialise(strSerialised) {
var entries = strSerialised.split("@");
var index = 0;
var i;
for (i=entries.length; i>0; i--) {
	this.queue[index].pageId = entries[i];
	this.queue[index].title = top.scripts.pageStore.getTitle(entries[i]);
	this.queue[index].href = top.scripts.pageStore.getHref(entries[i]);
	index++;
	if (index >= this.maxEntries) { break; }
	}
this.currentIndex = index - 1;
}
viewHistory.deserialise = historyDeserialise;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

// EOF