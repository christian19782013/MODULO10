// tocStore object
// Version 1.0 - Initial Framework Module - Rupert Davies
// (c) TSO 2001

// *** Objects ***
var tocStore = new Object();

function toc(root, currentPage, currentAnchor, tocBefore, tocAfter) {
	this.root = root;
	this.currentPage = currentPage;
	this.currentAnchor = currentAnchor;
	this.tocBefore = tocBefore;
	this.tocAfter = tocAfter;
}

function tocItem(id, anchor, state, branch) {
	this.id = id;
	this.anchor = anchor;
	this.state = state;
	this.branch = branch;
}


// *** Properties ***
tocStore.currentToc = "";


// *** Methods ***

function initTocStore() {
initTocStoreData();
}
tocStore.init = initTocStore;

function tocSetCurrent(tocId) {
this.currentToc = tocId;
}
tocStore.setCurrent = tocSetCurrent;


// Find next document in ToC
function tocGetNextPage(currentId) {
var resultId = "";
var tocId = this.currentToc;
if (currentId=="" || currentId==null) {
	currentId = this[tocId].currentPage;
	}
var docFound = false;
var lng = this[tocId].root.length;
var i = 0;
var j = 0;
// Root level checking loop
for (i=1; i<lng; i++) {
	if (docFound && resultId=="") {
		resultId = this[tocId].root[i].id;
		if (resultId == currentId) {
			resultId = "";
			}
		if (resultId!="") {
			if (!top.scripts.pageStore.exists(resultId)) {
				resultId = "";
				}
			else {
				break;
				}
			}
		}
	if (this[tocId].root[i].id==currentId) {
		docFound = true;
		}
// Level 1 checking loop
	if (this[tocId].root[i].branch[1]) {
		lng1 = this[tocId].root[i].branch.length;
		for (j=1; j<lng1; j++) {
			if (docFound && resultId=="") {
				resultId = this[tocId].root[i].branch[j].id;
				if (resultId==currentId) {
					resultId="";
					}
				if (resultId!="") {
					if (!top.scripts.pageStore.exists(resultId)) {
						resultId="";
						}
					else {
						break;
						}
					}
				}
			if (this[tocId].root[i].branch[j].id==currentId) {
				docFound=true;
				}
			}
// End level 1 loop
		}
// End root loop
	}
return (resultId);
}
tocStore.getNextPage = tocGetNextPage;


// Find previous document in ToC
function tocGetPrevPage(currentId) {
var resultId = "";
var tocId = this.currentToc;
if (currentId=="" || currentId==null) {
	currentId = this[tocId].currentPage;
	}
var docFound = false;
var lng = this[tocId].root.length;
var i = 0;
var j = 0;
// Root level checking loop
for (i=(lng-1); i>0; i--) {
	if (this[tocId].root[i].branch[1]) {
		lng1 = this[tocId].root[i].branch.length;
// Level 1 checking loop
		for (j=(lng1-1); j>0; j--) {
			if (docFound && resultId=="") {
				resultId = this[tocId].root[i].branch[j].id;
				if (resultId==currentId) {
					resultId = "";
					}
				if (resultId!="") {
					if (!top.scripts.pageStore.exists(resultId)) {
						resultId = "";
						}
					else {
						break;
						}
					}
				}
			if (this[tocId].root[i].branch[j].id==currentId) {
				docFound = true;
				}
			}
// End level 1 loop
		}
	if (docFound && resultId=="") {
		resultId = this[tocId].root[i].id;
		if (resultId==currentId) {
			resultId = "";
			}
		if (resultId!="") {
			if (!top.scripts.pageStore.exists(resultId)) {
				resultId = "";
				}
			else {
				break;
				}
			}
		}
	if (this[tocId].root[i].id==currentId) {
		docFound = true;
		}
// End root loop
	}
return (resultId);
}
tocStore.getPrevPage = tocGetPrevPage;

function tocSetCurrentPage(pageId) {
this[this.currentToc].currentPage = pageId;
}
tocStore.setCurrentPage = tocSetCurrentPage;

// Switch state flag for ToC node
function tocState(r,s) {
if (s==0) {
	this[this.currentToc].root[r].state = !this[this.currentToc].root[r].state;
	}
else {
	this[this.currentToc].root[r].branch[s].state = !this[this.currentToc].root[r].branch[s].state;
	}
}
tocStore.state = tocState;


// Set all state flags for ToC to closed (false)
function collapseToc() {
var tocId = this.currentToc;
var lng = this[tocId].root.length;
for (i=1; i<lng; i++) {
	this[tocId].root[i].state = 0;
	if (this[tocId].root[i].branch[1]) {
		var lng1 = this[tocId].root[i].branch.length;
		for (j=1; j<lng1; j++) {
			this[tocId].root[i].branch[j].state = 0;
			if (this[tocId].root[i].branch[j].branch[1]) {
				var lng2 = this[tocId].root[i].branch[j].branch.length;
				for (k=1; k<lng2; k++) {
					this[tocId].root[i].branch[j].branch[k].state = 0;
					}
				}
			}
		}
	}
}
tocStore.collapse = collapseToc;


// Set all state flags for ToC to open (true)
function expandToc() {
var tocId = this.currentToc;
var lng = this[tocId].root.length;
for (i=1; i<lng; i++) {
	this[tocId].root[i].state = 1;
	if (this[tocId].root[i].branch[1]) {
		var lng1 = this[tocId].root[i].branch.length;
		for (j=1; j<lng1; j++) {
			this[tocId].root[i].branch[j].state = 1;
			if (this[tocId].root[i].branch[j].branch[1]) {
				var lng2 = this[tocId].root[i].branch[j].branch.length;
				for (k=1; k<lng2; k++) {
					this[tocId].root[i].branch[j].branch[k].state = 1;
					}
				}
			}
		}
	}
}
tocStore.expand = expandToc;


// Find TOC that page belongs to by pageId
// Will only work accurately for publications where each page is in only one TOC.
function findToc(pageId) {
var result = -1;
var tocFound = false;
var obj;
for (obj in this) {
	if (this[obj].root) {	
		var lng = this[obj].root.length;
		var i = 0;
		var j = 0;
		// Root level checking loop
		for (i=1; i<lng; i++) {
			if (pageId==this[obj].root[i].id) {
				result = obj;
				break;
				}
			// Level 1 checking loop
			if (this[obj].root[i].branch[1]) {
				lng1 = this[obj].root[i].branch.length;
				for (j=1; j<lng1; j++) {
					if (pageId==this[obj].root[i].branch[j].id) {
						result = obj;
						break;
						}
					}
				}
			}
		}
	if (result!=-1) {
		break;
		}
	}
return (result);
}
tocStore.findToc = findToc;


// is page in this toc?
function inToc(tocId,pageId) {
var found = false;
	var lng = this[tocId].root.length;
	var i = 0;
	var j = 0;
	// Root level checking loop
	for (i=1; i<lng; i++) {
		if (pageId==this[tocId].root[i].id) {
			found = true;
			break;
			}
	// Level 1 checking loop
		if (this[tocId].root[i].branch[1]) {
			lng1 = this[tocId].root[i].branch.length;
			for (j=1; j<lng1; j++) {
				if (pageId==this[tocId].root[i].branch[j].id) {
					found = true;
					break;
					}
				}
	// End level 1 loop
			}
	// End root loop
		}
return (found);
}
tocStore.inToc = inToc;


// EOF