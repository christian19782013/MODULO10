// DOM TOC runtime functions
// CD Framework v.1.2 Module
// Rupert Davies - 2002-07-29

var eCurrent = null;

function init(tocId) {
if (typeof(document.addEventListener) == "function") {
	document.addEventListener("click", clickHandler, true);
	}
if (tocId=="" || tocId==null) {
	tocId = top.scripts.tocStore.currentToc;
	}
var lgt = top.scripts.tocStore[tocId].root.length;
for (i=1; i<lgt; i++) {
	if (top.scripts.tocStore[tocId].root[i].branch[1]) {
		var tempElement = document.getElementById(("toc_"+i));
		if (tempElement != null) {
			if (top.scripts.tocStore[top.scripts.tocStore.currentToc].root[i].state) {
				tempElement.className = "tocMinus";
				var ulElement = tempElement.getElementsByTagName('ul')[0];
				ulElement.style.display = "";
				}
			else {
				tempElement.className = "tocPlus";
				var ulElement = tempElement.getElementsByTagName('ul')[0];
				ulElement.style.display = "none";
				}
			}
		}
	}
top.scripts.display.highlightToc();
document.getElementById('tocControls').style.display = "block";
}

function toggle(source) {
var ulElement = source.getElementsByTagName('ul')[0];
var id = source.id;
var tocPosition = id.split("_");
var pos1 = tocPosition[1];
if (pos1 == null) { pos1 = 0; }
var pos2 = tocPosition[2];
if (pos2 == null) { pos2 = 0; }
top.scripts.tocStore.state(pos1, pos2);
if (ulElement.style.display == "none") {
	source.className = "tocMinus";
	ulElement.style.display = "";
	}
else {
	source.className = "tocPlus";
	ulElement.style.display = "none";
	}
}

function cancelEvent() {
if (typeof(window.event) == "object") {
	window.event.cancelBubble = true;
	}
if (eCurrent != null) {
	if (typeof(eCurrent.stopPropagation) == "function") {
		eCurrent.stopPropagation();
		}
	}
}

function clickHandler(e) {
	eCurrent = e;
}