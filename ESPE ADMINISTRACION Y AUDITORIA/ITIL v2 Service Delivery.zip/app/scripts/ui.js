// ui object
// CD Framework 1.2 Module
// Rupert Davies - 2002-06-14
// (c) 2002 TSO

// *** Objects ***

var ui = new Object();
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

function uiButton(uaObject, state, action, imgActive, imgOver, imgDisabled, imgHighlight) {
this.uaObject = uaObject; 		// Reference to the image object as part of the ua object model
this.state = state; 			// 'active' || 'disabled' || 'highlight'
this.action = action;
this.imgActive = imgActive;
this.imgOver = imgOver;
this.imgDisabled = imgDisabled;
this.imgHighlight = imgHighlight;

function buttOver() {
if (this.state == "active") {
	this.uaObject.src = this.imgOver.src;
	}
else {
	this.uaObject.src = this.imgDisabled.src;
	}
}
this.over = buttOver;

function buttOut() {
if (this.state == "active") {
	this.uaObject.src = this.imgActive.src;
	}
else {
	this.uaObject.src = this.imgDisabled.src;
	}
}
this.out = buttOut;

function buttClick() {
if (this.state != "disabled" ) {
	eval(this.action);
	}
}
this.click = buttClick;

function buttStateChange(state) {
this.state = state;
if (this.state == "active") {
	this.uaObject.src = this.imgActive.src;
	}
else if (this.state == "disabled") {
	this.uaObject.src = this.imgDisabled.src;
	}
else if (this.state == "highlight") {
	this.uaObject.src = this.imgHighlight.src;
	}
}
this.stateChange = buttStateChange;
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

// *** Properties ***

ui.navMode = "toc";
ui.navPaneVisible = false;
ui.pageContext = "default";
ui.enableShowHide = true;
ui.enableNext = true;
ui.enablePrev = true;
ui.enableHighlight = true;
ui.enableShowHistory = true;
ui.enableAddToHistory = true;
ui.enableShowBookmarks = true;
ui.enableToggleBookmark =true;
ui.peripheryPages = new Array("search", "advsearch", "acknow", "glossary", "contact", "feedback", "foreword", "help", "home", "info", "licence", "privacy", "process", "role", "standard", "templates");
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

// *** Methods ***

function uiSubmitSearch(query) {
if (!top.scripts.searchActive) {
	display.alert("The search function is not available for your current browser.");
	return;
	}
search.execute(query);
if (search.resultSet[0] < 1) {
	display.alert("Nothing Found.\nPlease refine your search and try again.");
	}
else if (search.resultSet[0] > 0) {
	ui.navMode = "search";
	ui.navModeChange();
	display.searchPage = 0;
	currentPageId = search.resultSet[1].pageId;
	ui.navPaneVisible = true;
	display.showNavPane();
	}
}
ui.submitSearch = uiSubmitSearch;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function uiShowHide() {
if (this.enableShowHide) {
	this.navPaneVisible = !this.navPaneVisible;
	if (this.navPaneVisible) {
		display.showNavPane();
		}
	else {
		display.showContentFull();
		}
	}
}
ui.showHide = uiShowHide;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function uiLoadToc(tocId) {
this.navMode = "toc";
this.navModeChange();
tocStore.setCurrent(tocId);
if (this.navPaneVisible) {
	display.updateContent();
	}
display.showNavPane();
this.navPaneVisible = true;
}
ui.loadToc = uiLoadToc;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function uiNext() {
if (this.enableNext) {
	if (this.navMode=="toc") {
		var nextPageId = tocStore.getNextPage();
		if (nextPageId != "") {
			tocStore.setCurrentPage(nextPageId);
			display.updateContent();
			}
		}
	}
}
ui.next = uiNext;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function uiPrev() {
if (this.enablePrev) {
	if (this.navMode=="toc") {
		var prevPageId = tocStore.getPrevPage();
		if (prevPageId != "") {
			tocStore.setCurrentPage(prevPageId);
			display.updateContent();
			}
		}
	}
}
ui.prev = uiPrev;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function uiCheckPageFeatures(pageId) {
if (isPeripheryPage(pageId)) {
	this.navMode = "periphery";
	this.navModeChange();
	}
}
ui.checkPageFeatures = uiCheckPageFeatures;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function uiNavModeChange() {
if (this.navMode == "periphery") {
	this.enableShowHide = false;
	this.enableNext = false;
	this.enablePrev = false;
	this.enableAddToHistory = false;
	this.enableToggleBookmark = false;
	display.updateButtons();
	}
else if (this.navMode == "toc") {
	this.enableShowHide = true;
	this.enableNext = true;
	this.enablePrev = true;
	this.enableAddToHistory = true;
	this.enableToggleBookmark = true;
	display.updateButtons();
	}
else if (this.navMode == "search") {
	this.enableShowHide = true;
	this.enableNext = false;
	this.enablePrev = false;
	this.enableAddToHistory = true;
	this.enableToggleBookmark = true;
	display.updateButtons();
	}
else if (this.navMode == "bookmark") {
	this.enableShowHide = true;
	this.enableNext = false;
	this.enablePrev = false;
	this.enableAddToHistory = true;
	this.enableToggleBookmark = true;
	display.updateButtons();
	}
else if (this.navMode == "history") {
	this.enableShowHide = true;
	this.enableNext = false;
	this.enablePrev = false;
	this.enableAddToHistory = true;
	this.enableToggleBookmark = true;
	display.updateButtons();
	}
}
ui.navModeChange = uiNavModeChange;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function isPeripheryPage(id) {
var i=0;
for (i = 0; i < ui.peripheryPages.length; i++) {
	if (id == ui.peripheryPages[i]) {
		return true;
		}
	}
return false;
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function uiShowOptions() {
var winFeatures = "width=300,height=180,scrollbars=yes,toolbar=no,menubar=no,resizable=yes";
window.open("options.htm","options", winFeatures);
}
ui.showOptions = uiShowOptions;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function uiShowToc() {
this.navMode = "toc";
ui.navModeChange();
display.showNavPane();
this.navPaneVisible = true;
}
ui.showToc = uiShowToc;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function uiShowHistory() {
if (this.enableShowHistory) {
	if (this.navMode != "history") {
		this.navMode = "history";
		ui.navModeChange();
		currentPageId = viewHistory.firstPageId();
		if (currentPageId == "") {
			currentPageId = defaultPageId;
			}
		display.updateContent();
		}
	display.showNavPane();
	this.navPaneVisible = true;
	}
}
ui.showHistory = uiShowHistory;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function uiShowBookmarks() {
if (this.enableShowBookmarks) {
	if (this.navMode != "bookmark") {
		this.navMode = "bookmark";
		ui.navModeChange();
		currentPageId = bookmarks.firstPageId();
		if (!pageStore.exists(currentPageId)) {
			currentPageId = defaultPageId;
			}
		display.updateContent();
		}
	display.showNavPane();
	this.navPaneVisible = true;
	}
}
ui.showBookmarks = uiShowBookmarks;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function uiToggleBookmark(pageId) {
if (pageId == null) {
	pageId = top.scripts.currentPageId;
	}
if (this.enableToggleBookmark) {
	top.scripts.bookmarks.toggle(pageId);
	display.updateBookmarkFlag(pageId);
	if (this.navMode == "bookmark" && this.navPaneVisible) {
		display.showNavPane();
		}
	if (top.scripts.NS4 || top.scripts.NS6 || top.scripts.NS7 || top.scripts.MOZ || top.scripts.OP6) {
		session.save();
		}
	}
}
ui.toggleBookmark = uiToggleBookmark;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function uiClearBookmark(pageId) {
if (pageId == null) {
	pageId = top.scripts.currentPageId;
	}
top.scripts.bookmarks.clear(pageId);
if (currentPageId == pageId) {
	display.bookmarkOff();
	}
if (this.navMode == "bookmark" && this.navPaneVisible) {
	display.showNavPane();
	}
if (top.scripts.NS4 || top.scripts.NS6 || top.scripts.NS7 || top.scripts.MOZ || top.scripts.OP6) {
	session.save();
	}
}
ui.clearBookmark = uiClearBookmark;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


// EOF