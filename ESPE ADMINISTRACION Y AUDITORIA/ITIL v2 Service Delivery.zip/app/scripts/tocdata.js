// tocStore data
// ITIL Series - TOC data
// Version 1.0
// Rupert Davies - 2002-06-26

function initTocStoreData() {

tocStore.currentToc = "contents";

// toc - id: contents

tocStore.contents = new toc("","sd_2",0,0,0);

tocStore.contents.root = new Array();


tocStore.contents.root[1] = new tocItem("sd_2","",0,0);

tocStore.contents.root[2] = new tocItem("sd_5","",0,0);

tocStore.contents.root[2].branch = new Array();

tocStore.contents.root[2].branch[1] = new tocItem("sd_6","",0,0);
tocStore.contents.root[2].branch[2] = new tocItem("sd_7","",0,0);
tocStore.contents.root[2].branch[3] = new tocItem("sd_8","",0,0);
tocStore.contents.root[2].branch[4] = new tocItem("sd_9","",0,0);
tocStore.contents.root[2].branch[5] = new tocItem("sd_10","",0,0);
tocStore.contents.root[2].branch[6] = new tocItem("sd_11","",0,0);
tocStore.contents.root[2].branch[7] = new tocItem("sd_12","",0,0);
tocStore.contents.root[2].branch[8] = new tocItem("sd_13","",0,0);
tocStore.contents.root[2].branch[9] = new tocItem("sd_14","",0,0);
tocStore.contents.root[2].branch[10] = new tocItem("sd_15","",0,0);
tocStore.contents.root[2].branch[11] = new tocItem("sd_16","",0,0);

tocStore.contents.root[3] = new tocItem("sd_17","",0,0);

tocStore.contents.root[3].branch = new Array();

tocStore.contents.root[3].branch[1] = new tocItem("sd_18","",0,0);
tocStore.contents.root[3].branch[2] = new tocItem("sd_19","",0,0);
tocStore.contents.root[3].branch[3] = new tocItem("sd_20","",0,0);
tocStore.contents.root[3].branch[4] = new tocItem("sd_21","",0,0);
tocStore.contents.root[3].branch[5] = new tocItem("sd_22","",0,0);
tocStore.contents.root[3].branch[6] = new tocItem("sd_23","",0,0);
tocStore.contents.root[3].branch[7] = new tocItem("sd_24","",0,0);
tocStore.contents.root[3].branch[8] = new tocItem("sd_25","",0,0);
tocStore.contents.root[3].branch[9] = new tocItem("sd_26","",0,0);
tocStore.contents.root[3].branch[10] = new tocItem("sd_27","",0,0);
tocStore.contents.root[3].branch[11] = new tocItem("sd_28","",0,0);
tocStore.contents.root[3].branch[12] = new tocItem("sd_29","",0,0);
tocStore.contents.root[3].branch[13] = new tocItem("sd_30","",0,0);
tocStore.contents.root[3].branch[14] = new tocItem("sd_31","",0,0);
tocStore.contents.root[3].branch[15] = new tocItem("sd_32","",0,0);
tocStore.contents.root[3].branch[16] = new tocItem("sd_33","",0,0);

tocStore.contents.root[4] = new tocItem("sd_34","",0,0);

tocStore.contents.root[4].branch = new Array();

tocStore.contents.root[4].branch[1] = new tocItem("sd_35","",0,0);
tocStore.contents.root[4].branch[2] = new tocItem("sd_36","",0,0);
tocStore.contents.root[4].branch[3] = new tocItem("sd_37","",0,0);
tocStore.contents.root[4].branch[4] = new tocItem("sd_38","",0,0);

tocStore.contents.root[5] = new tocItem("sd_39","",0,0);

tocStore.contents.root[5].branch = new Array();

tocStore.contents.root[5].branch[1] = new tocItem("sd_40","",0,0);
tocStore.contents.root[5].branch[2] = new tocItem("sd_41","",0,0);
tocStore.contents.root[5].branch[3] = new tocItem("sd_42","",0,0);
tocStore.contents.root[5].branch[4] = new tocItem("sd_43","",0,0);
tocStore.contents.root[5].branch[5] = new tocItem("sd_44","",0,0);
tocStore.contents.root[5].branch[6] = new tocItem("sd_45","",0,0);
tocStore.contents.root[5].branch[7] = new tocItem("sd_46","",0,0);
tocStore.contents.root[5].branch[8] = new tocItem("sd_47","",0,0);
tocStore.contents.root[5].branch[9] = new tocItem("sd_48","",0,0);
tocStore.contents.root[5].branch[10] = new tocItem("sd_49","",0,0);
tocStore.contents.root[5].branch[11] = new tocItem("sd_50","",0,0);
tocStore.contents.root[5].branch[12] = new tocItem("sd_51","",0,0);
tocStore.contents.root[5].branch[13] = new tocItem("sd_52","",0,0);

tocStore.contents.root[6] = new tocItem("sd_53","",0,0);

tocStore.contents.root[6].branch = new Array();

tocStore.contents.root[6].branch[1] = new tocItem("sd_54","",0,0);
tocStore.contents.root[6].branch[2] = new tocItem("sd_55","",0,0);
tocStore.contents.root[6].branch[3] = new tocItem("sd_56","",0,0);
tocStore.contents.root[6].branch[4] = new tocItem("sd_57","",0,0);
tocStore.contents.root[6].branch[5] = new tocItem("sd_58","",0,0);
tocStore.contents.root[6].branch[6] = new tocItem("sd_59","",0,0);
tocStore.contents.root[6].branch[7] = new tocItem("sd_60","",0,0);
tocStore.contents.root[6].branch[8] = new tocItem("sd_61","",0,0);

tocStore.contents.root[7] = new tocItem("sd_62","",0,0);

tocStore.contents.root[7].branch = new Array();

tocStore.contents.root[7].branch[1] = new tocItem("sd_63","",0,0);
tocStore.contents.root[7].branch[2] = new tocItem("sd_64","",0,0);
tocStore.contents.root[7].branch[3] = new tocItem("sd_65","",0,0);
tocStore.contents.root[7].branch[4] = new tocItem("sd_66","",0,0);
tocStore.contents.root[7].branch[5] = new tocItem("sd_67","",0,0);
tocStore.contents.root[7].branch[6] = new tocItem("sd_68","",0,0);
tocStore.contents.root[7].branch[7] = new tocItem("sd_69","",0,0);
tocStore.contents.root[7].branch[8] = new tocItem("sd_70","",0,0);
tocStore.contents.root[7].branch[9] = new tocItem("sd_71","",0,0);

tocStore.contents.root[8] = new tocItem("sd_72","",0,0);

tocStore.contents.root[8].branch = new Array();

tocStore.contents.root[8].branch[1] = new tocItem("sd_73","",0,0);
tocStore.contents.root[8].branch[2] = new tocItem("sd_74","",0,0);
tocStore.contents.root[8].branch[3] = new tocItem("sd_75","",0,0);
tocStore.contents.root[8].branch[4] = new tocItem("sd_76","",0,0);
tocStore.contents.root[8].branch[5] = new tocItem("sd_77","",0,0);
tocStore.contents.root[8].branch[6] = new tocItem("sd_78","",0,0);
tocStore.contents.root[8].branch[7] = new tocItem("sd_79","",0,0);
tocStore.contents.root[8].branch[8] = new tocItem("sd_80","",0,0);
tocStore.contents.root[8].branch[9] = new tocItem("sd_81","",0,0);
tocStore.contents.root[8].branch[10] = new tocItem("sd_82","",0,0);
tocStore.contents.root[8].branch[11] = new tocItem("sd_83","",0,0);
tocStore.contents.root[8].branch[12] = new tocItem("sd_84","",0,0);
tocStore.contents.root[8].branch[13] = new tocItem("sd_85","",0,0);
tocStore.contents.root[8].branch[14] = new tocItem("sd_86","",0,0);
tocStore.contents.root[8].branch[15] = new tocItem("sd_87","",0,0);
tocStore.contents.root[8].branch[16] = new tocItem("sd_88","",0,0);
tocStore.contents.root[8].branch[17] = new tocItem("sd_89","",0,0);
tocStore.contents.root[8].branch[18] = new tocItem("sd_90","",0,0);
tocStore.contents.root[8].branch[19] = new tocItem("sd_91","",0,0);
tocStore.contents.root[8].branch[20] = new tocItem("sd_92","",0,0);
tocStore.contents.root[8].branch[21] = new tocItem("sd_93","",0,0);
tocStore.contents.root[8].branch[22] = new tocItem("sd_94","",0,0);

tocStore.contents.root[9] = new tocItem("sd_95","",0,0);

tocStore.contents.root[9].branch = new Array();

tocStore.contents.root[9].branch[1] = new tocItem("sd_96","",0,0);
tocStore.contents.root[9].branch[2] = new tocItem("sd_97","",0,0);
tocStore.contents.root[9].branch[3] = new tocItem("sd_98","",0,0);
tocStore.contents.root[9].branch[4] = new tocItem("sd_99","",0,0);
tocStore.contents.root[9].branch[5] = new tocItem("sd_100","",0,0);
tocStore.contents.root[9].branch[6] = new tocItem("sd_101","",0,0);
tocStore.contents.root[9].branch[7] = new tocItem("sd_102","",0,0);
tocStore.contents.root[9].branch[8] = new tocItem("sd_103","",0,0);
tocStore.contents.root[9].branch[9] = new tocItem("sd_104","",0,0);
tocStore.contents.root[9].branch[10] = new tocItem("sd_105","",0,0);

tocStore.contents.root[10] = new tocItem("sd_106","",0,0);

tocStore.contents.root[10].branch = new Array();

tocStore.contents.root[10].branch[1] = new tocItem("sd_107","",0,0);
tocStore.contents.root[10].branch[2] = new tocItem("sd_108","",0,0);
tocStore.contents.root[10].branch[3] = new tocItem("sd_109","",0,0);

tocStore.contents.root[11] = new tocItem("sd_110","",0,0);

tocStore.contents.root[11].branch = new Array();

tocStore.contents.root[11].branch[1] = new tocItem("sd_111","",0,0);
tocStore.contents.root[11].branch[2] = new tocItem("sd_112","",0,0);
tocStore.contents.root[11].branch[3] = new tocItem("sd_113","",0,0);
tocStore.contents.root[11].branch[4] = new tocItem("sd_114","",0,0);
tocStore.contents.root[11].branch[5] = new tocItem("sd_115","",0,0);

tocStore.contents.root[12] = new tocItem("sd_116","",0,0);

tocStore.contents.root[12].branch = new Array();

tocStore.contents.root[12].branch[1] = new tocItem("sd_117","",0,0);
tocStore.contents.root[12].branch[2] = new tocItem("sd_118","",0,0);

tocStore.contents.root[13] = new tocItem("sd_119","",0,0);

tocStore.contents.root[13].branch = new Array();

tocStore.contents.root[13].branch[1] = new tocItem("sd_120","",0,0);
tocStore.contents.root[13].branch[2] = new tocItem("sd_121","",0,0);

tocStore.contents.root[14] = new tocItem("sd_122","",0,0);

tocStore.contents.root[14].branch = new Array();

tocStore.contents.root[14].branch[1] = new tocItem("sd_123","",0,0);

tocStore.contents.root[15] = new tocItem("sd_124","",0,0);

tocStore.contents.root[15].branch = new Array();

tocStore.contents.root[15].branch[1] = new tocItem("sd_125","",0,0);
tocStore.contents.root[15].branch[2] = new tocItem("sd_126","",0,0);
tocStore.contents.root[15].branch[3] = new tocItem("sd_127","",0,0);
tocStore.contents.root[15].branch[4] = new tocItem("sd_128","",0,0);
tocStore.contents.root[15].branch[5] = new tocItem("sd_129","",0,0);
tocStore.contents.root[15].branch[6] = new tocItem("sd_130","",0,0);
tocStore.contents.root[15].branch[7] = new tocItem("sd_131","",0,0);

tocStore.contents.root[16] = new tocItem("sd_132","",0,0);

tocStore.contents.root[16].branch = new Array();

tocStore.contents.root[16].branch[1] = new tocItem("sd_133","",0,0);
tocStore.contents.root[16].branch[2] = new tocItem("sd_134","",0,0);

tocStore.contents.root[17] = new tocItem("sd_135","",0,0);

tocStore.contents.root[17].branch = new Array();

tocStore.contents.root[17].branch[1] = new tocItem("sd_136","",0,0);
tocStore.contents.root[17].branch[2] = new tocItem("sd_137","",0,0);
tocStore.contents.root[17].branch[3] = new tocItem("sd_138","",0,0);
tocStore.contents.root[17].branch[4] = new tocItem("sd_139","",0,0);

tocStore.contents.root[18] = new tocItem("sd_140","",0,0);

tocStore.contents.root[19] = new tocItem("sd_141","",0,0);

tocStore.contents.root[20] = new tocItem("","",0,0);

tocStore.contents.root[20].branch = new Array();

tocStore.contents.root[20].branch[1] = new tocItem("sd_9","f1_1",0,0);
tocStore.contents.root[20].branch[2] = new tocItem("sd_11","f1_2",0,0);
tocStore.contents.root[20].branch[3] = new tocItem("sd_14","f1_3",0,0);
tocStore.contents.root[20].branch[4] = new tocItem("sd_23","f2_1",0,0);
tocStore.contents.root[20].branch[5] = new tocItem("sd_36","f3_1",0,0);
tocStore.contents.root[20].branch[6] = new tocItem("sd_36","f3_2",0,0);
tocStore.contents.root[20].branch[7] = new tocItem("sd_40","f4_1",0,0);
tocStore.contents.root[20].branch[8] = new tocItem("sd_41","f4_2",0,0);
tocStore.contents.root[20].branch[9] = new tocItem("sd_43","f4_3",0,0);
tocStore.contents.root[20].branch[10] = new tocItem("sd_43","f4_4",0,0);
tocStore.contents.root[20].branch[11] = new tocItem("sd_54","f5_1",0,0);
tocStore.contents.root[20].branch[12] = new tocItem("sd_54","f5_2",0,0);
tocStore.contents.root[20].branch[13] = new tocItem("sd_56","f5_3",0,0);
tocStore.contents.root[20].branch[14] = new tocItem("sd_56","f5_4",0,0);
tocStore.contents.root[20].branch[15] = new tocItem("sd_56","f5_5",0,0);
tocStore.contents.root[20].branch[16] = new tocItem("sd_63","f6_1",0,0);
tocStore.contents.root[20].branch[17] = new tocItem("sd_63","f6_2",0,0);
tocStore.contents.root[20].branch[18] = new tocItem("sd_64","f6_3",0,0);
tocStore.contents.root[20].branch[19] = new tocItem("sd_64","f6_4",0,0);
tocStore.contents.root[20].branch[20] = new tocItem("sd_64","f6_5",0,0);
tocStore.contents.root[20].branch[21] = new tocItem("sd_65","f6_6",0,0);
tocStore.contents.root[20].branch[22] = new tocItem("sd_65","f6_7",0,0);
tocStore.contents.root[20].branch[23] = new tocItem("sd_75","f7_1",0,0);
tocStore.contents.root[20].branch[24] = new tocItem("sd_75","f7_2",0,0);
tocStore.contents.root[20].branch[25] = new tocItem("sd_75","f7_3",0,0);
tocStore.contents.root[20].branch[26] = new tocItem("sd_75","f7_4",0,0);
tocStore.contents.root[20].branch[27] = new tocItem("sd_75","f7_5",0,0);
tocStore.contents.root[20].branch[28] = new tocItem("sd_75","f7_6",0,0);
tocStore.contents.root[20].branch[29] = new tocItem("sd_75","f7_7",0,0);
tocStore.contents.root[20].branch[30] = new tocItem("sd_75","f7_8",0,0);
tocStore.contents.root[20].branch[31] = new tocItem("sd_76","f7_9",0,0);
tocStore.contents.root[20].branch[32] = new tocItem("sd_76","f7_10",0,0);
tocStore.contents.root[20].branch[33] = new tocItem("sd_76","f7_11",0,0);
tocStore.contents.root[20].branch[34] = new tocItem("sd_97","f8_1",0,0);
tocStore.contents.root[20].branch[35] = new tocItem("sd_97","f8_2",0,0);
tocStore.contents.root[20].branch[36] = new tocItem("sd_97","f8_3",0,0);
tocStore.contents.root[20].branch[37] = new tocItem("sd_97","f8_4",0,0);
tocStore.contents.root[20].branch[38] = new tocItem("sd_98","f8_5",0,0);
tocStore.contents.root[20].branch[39] = new tocItem("sd_99","f8_6",0,0);
tocStore.contents.root[20].branch[40] = new tocItem("sd_99","f8_7",0,0);
tocStore.contents.root[20].branch[41] = new tocItem("sd_100","f8_8",0,0);
tocStore.contents.root[20].branch[42] = new tocItem("sd_100","f8_9",0,0);
tocStore.contents.root[20].branch[43] = new tocItem("sd_102","f8_10",0,0);
tocStore.contents.root[20].branch[44] = new tocItem("sd_102","f8_11",0,0);
tocStore.contents.root[20].branch[45] = new tocItem("sd_104","f8_12",0,0);
tocStore.contents.root[20].branch[46] = new tocItem("sd_104","f8_13",0,0);
tocStore.contents.root[20].branch[47] = new tocItem("sd_104","f8_14",0,0);
tocStore.contents.root[20].branch[48] = new tocItem("sd_104","f8_15",0,0);
tocStore.contents.root[20].branch[49] = new tocItem("sd_104","f8_16",0,0);
tocStore.contents.root[20].branch[50] = new tocItem("sd_104","f8_17",0,0);
tocStore.contents.root[20].branch[51] = new tocItem("sd_104","f8_18",0,0);
tocStore.contents.root[20].branch[52] = new tocItem("sd_104","f8_19",0,0);
tocStore.contents.root[20].branch[53] = new tocItem("sd_104","f8_20",0,0);
tocStore.contents.root[20].branch[54] = new tocItem("sd_104","f8_21",0,0);
tocStore.contents.root[20].branch[55] = new tocItem("sd_123","fb_1",0,0);
tocStore.contents.root[20].branch[56] = new tocItem("sd_123","fb_2",0,0);
tocStore.contents.root[20].branch[57] = new tocItem("sd_133","fd_1",0,0);
tocStore.contents.root[20].branch[58] = new tocItem("sd_133","fd_2",0,0);
tocStore.contents.root[20].branch[59] = new tocItem("sd_134","fd_3",0,0);

tocStore.contents.root[21] = new tocItem("","",0,0);

tocStore.contents.root[21].branch = new Array();

tocStore.contents.root[21].branch[1] = new tocItem("sd_55","t5_1",0,0);
tocStore.contents.root[21].branch[2] = new tocItem("sd_55","t5_2",0,0);
tocStore.contents.root[21].branch[3] = new tocItem("sd_56","t5_3",0,0);
tocStore.contents.root[21].branch[4] = new tocItem("sd_56","t5_4",0,0);
tocStore.contents.root[21].branch[5] = new tocItem("sd_56","t5_5",0,0);
tocStore.contents.root[21].branch[6] = new tocItem("sd_56","t5_6",0,0);
tocStore.contents.root[21].branch[7] = new tocItem("sd_56","t5_7",0,0);
tocStore.contents.root[21].branch[8] = new tocItem("sd_56","t5_8",0,0);
tocStore.contents.root[21].branch[9] = new tocItem("sd_57","t5_9",0,0);
tocStore.contents.root[21].branch[10] = new tocItem("sd_65","t6_1",0,0);
tocStore.contents.root[21].branch[11] = new tocItem("sd_75","t7_1",0,0);
tocStore.contents.root[21].branch[12] = new tocItem("sd_104","t8_1",0,0);
tocStore.contents.root[21].branch[13] = new tocItem("sd_104","t8_2",0,0);
tocStore.contents.root[21].branch[14] = new tocItem("sd_104","t8_3",0,0);
tocStore.contents.root[21].branch[15] = new tocItem("sd_104","t8_4",0,0);
tocStore.contents.root[21].branch[16] = new tocItem("sd_104","t8_5",0,0);

}

// EOF
