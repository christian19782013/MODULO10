// search Object
// Version 1.0 - Initial Framework Module - Rupert Davies
// (c) 2001 TSO


// *** Objects ***

var search = new Object();
search.resultSet = new Array();
var searchApp = null;

function resultRecord (relevance, location, title, pageId) {
	this.relevance = relevance;
	this.location = location;
	this.title = title;
	this.pageId = pageId;
}


// *** Properties ***

search.resultSet[0] = 0;
search.maxHits = 100;
search.sortBy = 0;
search.sortTypes = new Array("relevance", "title", "date");
search.stopWords = new Array("of", "the", "in", "from", "etc", "for", "by", "&", "to", "other", "no.", "at", "if", "it", "on", ".", "a", "be");
search.booleanWords = new Array("and", "or", "not");
search.newSearch = true;
search.inSearch = false;
search.lastQuery = " ";
search.keywords = "";
search.phrase = false;


// *** Methods ***

function searchInit() {
searchApp = top.applets.document.search;
}
search.init = searchInit;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function executeSearch(query) {
if (query != this.lastQuery) {
	this.inSearch = false;
	}
this.lastQuery = query;
if (!this.inSearch) {
	this.inSearch = true;
	// query = removeStopWords(query);
	query = booleanToUpperCase(query);
	if (query == null || query.length == 0)  {
		display.alert("Search Error.\nQuery only contained stop words.");
		this.inSearch = false;
		return false;
		}
	searchApp.setQuery(query);
	var noResults = searchApp.doSearch();
	if (noResults < 0) {
		display.alert("Search Error");
		this.inSearch = false;
		return false;
		}
	else {
		this.keywords = removeWords((""+searchApp.getKeywords()), this.booleanWords);
		// alert("Keywords: "+this.keywords);
		// alert("Documents found: "+noResults);
		this.resultSet[0] = noResults;
		for (i=0; i < noResults; i++) {
			var hitLoc = "" + searchApp.getHitLocation(i);
			// must remove '../Publication/' from hit location string
			// hitLoc = "content" + hitLoc; // + hitLoc.substring(15, (hitLoc.length));
			this.resultSet[i + 1] = new resultRecord(searchApp.getHitScore(i), hitLoc, searchApp.getHitTitle(i), searchApp.getHitField(i, "pageid"));
			}
		}
	}
return true;
}
search.execute = executeSearch;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function removeWords(string, removeArray) {
var returnString = "";
var word = "";
if (string.length > 0) {
	var wordsArray = string.split(" ");
	for (i = 0; i<wordsArray.length; i++) {
		word = wordsArray[i];
		if (word.length > 0) {
			if (!isRemoveWord(word, removeArray)) {
				returnString = returnString + " " + word;
				}
			}
		}
	}
return returnString;
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function isRemoveWord(string, removeArray) {
var lcString = string.toLowerCase();
for (j = 0; j<removeArray.length; j++) {
	if (lcString == removeArray[j]) {
		return true;
		}
	}
return false;
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


function booleanToUpperCase(queryString) {
var returnString = "";
var word = "";
if (queryString.length > 0) {
	var wordsArray = queryString.split(" ");
	for (i = 0; i<wordsArray.length; i++) {
		word = wordsArray[i];
		if (word.length > 0) {
			if (word.toLowerCase() == "and") {
				returnString = returnString + " AND";
				}
			else if (word.toLowerCase() == "or") {
				returnString = returnString + " OR";
				}
			else if (word.toLowerCase() == "not") {
				returnString = returnString + " NOT";
				}
			else {
				returnString = returnString + " " + word;
				}
			}
		}
	}
// alert("queryString: " + returnString);
return returnString;
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

// EOF