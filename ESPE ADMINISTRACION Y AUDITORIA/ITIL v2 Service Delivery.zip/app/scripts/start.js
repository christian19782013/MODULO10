// Start page functions
// CD Framework 1.2 Module
// 2002-05-29 - Rupert Davies
// (c) 2002 TSO


// Only allow valid browsers to proceed to frameset
function proceed() {

var msgDeny = "Sorry - Your current browser does not support this product\nPlease use Internet Explorer 4, 5, or 6, or Netscape 4 or 6\nVersions of both are included on the CD. See instruction booklet for installation details.";
var msgBuggy = "You are using an early version of Internet Explorer 4.\nThere are some known bugs in this version that affect this product, and we would recommend that you upgrade your browser. A later version of Internet Explorer is included on the CD. See instruction booklet for installation details.";
var msgNs7 = "Sorry - Netscape 7 is not yet fully supported for this product.\nThe search function will not be available, however you will be able to browse the content.";
var msgOp6 = "Sorry - Opera is not currently fully supported for this product.\nThe search function will not be available, however you will be able to browse the content.";
var msgMoz = "Sorry - Mozilla is not currently fully supported for this product.\nThe search function will not be available, however you will be able to browse the content.";

// Warn users of IE4 (first release) about possible bugs
if (IE4early) {
	alert(msgBuggy);
	}

// Let these browsers continue
if (IE4 || NS4 || IE5 || IE5_5 || IE6 || NS6) {
	window.location = "app/frames.htm";
	}

// Alert NS7 users and redirect to non-search frameset
else if (NS7) {
	alert(msgNs7);
	window.location = "app/alt_frames.htm";
	}

// Alert Opera 4/5 users and deny access
else if (OP4 || OP5) {
	alert(msgDeny);
	}

// Alert Opera 6 users and redirect to non-search frameset
else if (OP6) {
	alert(msgOp6);
	window.location = "app/alt_frames.htm";
	}

// Alert Mozilla users and redirect to non-search frameset
else if (MOZ) {
	alert(msgMoz);
	window.location = "app/alt_frames.htm";
	}

// Deny access to all other browsers
else {
	alert(msgDeny);
	}

}

// Break out of frameset at load time
function checkFrame() {
if (window.self != top) {
	window.top.location = self.location;
	}
}