// Browser checking functions
// CD Framework 1.2 Module
// Rupert Davies - 2002-06-06
// (c) 2002 TSO

// General features eg. browser object model
var DOM = false;
var IE = false;
var NS = false;

// Specific UA versions
var NS4 = false;
var NS6 = false;
var NS7 = false;
var MOZ = false;
var IE6 = false;
var IE5_5 = false;
var IE5 = false;
var IE4 = false;
var IE4early = false;
var OP4 = false;
var OP5 = false;
var OP6 = false;

function checkBrowser() {
var agent = navigator.userAgent.toLowerCase();
var app = navigator.appName.toLowerCase();
var codeName = navigator.appCodeName.toLowerCase();
var majorVersion = parseInt(navigator.appVersion);
var minorVersion = parseFloat(navigator.appVersion);
// alert("agent: " + agent + "\nappName: " + app + "\nappCodeName: " + codeName + "\nmajor ver: " + majorVersion + "\nminor ver: " + minorVersion);

if (agent.indexOf('opera') != -1) {
	OP6 = (agent.indexOf('opera 6') != -1 || agent.indexOf('opera/6') != -1) ? true:false;
	OP5 = (agent.indexOf('opera 5') != -1 || agent.indexOf('opera/5') != -1) ? true:false;
	OP4 = (agent.indexOf('opera 4') != -1 || agent.indexOf('opera/4') != -1) ? true:false;
	if (OP5 || OP6) {
		DOM = true;
		}
	}
else {
	if (agent.indexOf('netscape') != -1) {
		NS6 = (agent.indexOf('netscape6') != -1) ? true:false;
		NS7 = (agent.indexOf('netscape/7') != -1) ? true:false;
		}
	if (agent.indexOf('gecko') != -1 & !NS6 & !NS7) {
		MOZ = true;
		}
	if (app.indexOf('netscape') != -1) {
		NS4 = (majorVersion == 4) ? true:false;
		}
	if (NS6 || NS7 || MOZ) {
		DOM = true;
		}
	else if (NS4) {
		NS = true;
		}
	if (agent.indexOf('msie') != -1) {
		var brk = agent.indexOf(";") + 7;
		var lng = agent.length;
		var ieVer = agent.substring(brk,lng);
		brk = ieVer.indexOf(";");
		ieVer = ieVer.substring(0,brk);
		var ieMajVer = ieVer.split(".")[0];
		var ieMinVer = ieVer.split(".")[1];
		IE6 = (agent.indexOf('msie 6') != -1) ? true:false;
		IE5_5 = (agent.indexOf('msie 5.5') != -1) ? true:false;
		IE5 = ((document.all) && (window.print) && !(IE5_5 || IE6)) ? true:false;
		IE4 = ((document.all) && (!window.print)) ? true:false;
		if (IE4) {
			var brk = agent.indexOf(";") + 2;
			var lng = agent.length;
			var minVer = agent.substring(brk,lng);
			brk = minVer.indexOf(";");
			minVer = minVer.substring(0,brk);
			if (minVer == "msie 4.0") {
				IE4early = true;
				}
			}
		if (IE6 || ieMajVer >=6) {
			DOM = true;
			}
		else if (document.all) {
			IE = true;
			}
		}
	}
// alert("NS4: " + NS4 + "\nNS6: " + NS6 + "\nNS7: " + NS7 + "\nIE4: " + IE4 + "\nIE4 early: " + IE4early + "\nIE5: " + IE5 + "\nIE5.5: " + IE5_5 + "\nOP5: " + OP5 + "\nOP4: " + OP4 + "\nMOZ: " + MOZ);
// alert("DOM: " + DOM + "\nIE: " + IE + "\nNS: " + NS);
}

// EOF

