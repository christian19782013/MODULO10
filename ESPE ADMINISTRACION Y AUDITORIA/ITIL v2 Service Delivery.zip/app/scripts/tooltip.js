// Tooltip Display functions
// (c) TSO 2001
// Version 2.1 - Rupert Davies
// Added NS6 compatibility - 2001-04-30
// Added IE6 compatMode fix - 2001-10-30

var NS4 = (document.layers) ? true : false;
var IE = (document.all) ? true : false;
var NS6 = ((navigator.appName.toLowerCase().indexOf('netscape')!=-1) && ((parseInt(navigator.appVersion))==5)) ? true : false;
var platWin = (navigator.userAgent.toLowerCase().indexOf('win')!=-1) ? true : false;
var x = 0;
var y = 0;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// Must be called on document load to initialise event capturing
function initTip() {
if (NS6) {
	document.addEventListener("mousemove", mouseMove, true);
	}
if ((NS4)||(IE)) {
	document.onmousemove = mouseMove;
	if (NS4) {document.captureEvents(Event.MOUSEMOVE) };
	}
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


function mouseMove(e) {
if (NS4 || NS6) {
	x = e.pageX;
	y = e.pageY;
// Could also use e.clientX + window.scrollX for NS6
	}
if (IE) {
	var compatMode = document.compatMode;
// IE6 - compatMode = 'BackCompat' : 'CSS1Compat', for all others should be null
	if (compatMode == "CSS1Compat") {
// IE6 in CSS compatibility mode takes the html element as the canvas, instead of the body element
		x = window.event.x + document.getElementsByTagName('html')[0].scrollLeft;
		y = window.event.y + document.getElementsByTagName('html')[0].scrollTop;
		}
	else {
		x = window.event.clientX + document.body.scrollLeft;
		y = window.event.clientY + document.body.scrollTop;
		}
	// window.status = "X:" + x + " Y:" + y + " - scrollTop:" + document.getElementsByTagName('html')[0].scrollTop + " - compatMode: " + compatMode;
	}
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


function showTip(txt) {
var tipColour = "#FFFFCC";
if (IE && platWin) {
	var tooltip = document.all['tooltip'];
	content="<table width='200' border='0' cellpadding='0' cellspacing='0'><tr><td><table id='outerTip' border='0' cellpadding='1' cellspacing='0' bgcolor='#000000'><tr><td><table width='100%' cellpadding='2' bgcolor='"+tipColour+"' cellspacing='0' border='0'><tr><td class='tip'>"+txt+"</td></tr></table></td></tr></table></td></tr></table>";
	tooltip.innerHTML = content;
	var tipWidth = outerTip.clientWidth;
	x-=tipWidth;
	if (x<5) x=5;
	tooltip.style.left = (x+5);
	tooltip.style.top = (y+15);
	tooltip.style.visibility = 'visible';
	}

// Styling properties for NS6 are set through CSS on #innerTip
if (NS6) {
	var tooltip = document.getElementById("tooltip");
	content = "<div id='innerTip' style='background-color: " + tipColour + ";'>" + txt + "</div>";
	tooltip.innerHTML = content;
	var tipWidth = document.getElementById('innerTip').offsetWidth;
	var pageWidth = document.width;
	if ((x+tipWidth)>pageWidth) {x = (pageWidth-tipWidth);}
	tooltip.style.left = (x+5) + "px";
	tooltip.style.top = (y+15) + "px";
	tooltip.style.visibility = 'visible';
	}

if (NS4) {
	content = "<table width='200' border='0' cellpadding='0' cellspacing='0'><tr><td><table border='0' cellpadding='1' cellspacing='0' bgcolor='#000000'><tr><td><table width='100%' cellpadding='2' bgcolor='" + tipColour + "' cellspacing='0' border='0'><tr><td class='tip'>" + txt + "</td></tr></table></td></tr></table></td></tr></table>";
	document.tooltip.document.write(content);
	document.tooltip.document.close();
// dodgy work-around to detect the width of the tooltip
	var chrs = txt.length;
	var offset = 200;
	if (chrs < 40) {
		offset = chrs * 7;
		}
	x -= offset;
	if (x < 5) x = 5;
	document.tooltip.left = (x+5);
	document.tooltip.top = (y+15);
	document.tooltip.visibility = 'show';
	}
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


function hideTip() {
if ((IE && platWin) || NS6) {
	if (NS6) {
		var tooltip = document.getElementById("tooltip");
		}
	else {
		var tooltip = document.all['tooltip'];
		}
	tooltip.style.visibility = 'hidden';
	tooltip.style.left = 0;
	tooltip.style.top = 0;
	}
if (NS4) {
	document.tooltip.visibility = 'hide';
	document.tooltip.left = 0;
	document.tooltip.top = 0;
	}
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// EOF